<?php

/**
 * Enqueue scripts and styles.
 */
function medilac_core_enqueue() {
    
    /**
     * Different Type Layout
     * Such: Header One Two Style
     * Footer One Two Style
     * Basically for different type style, We have used this layout.css file
     * 
     * @since 1.0.0.14
     */
    wp_enqueue_style( 'medilac-core-style', MEDILAC_CORE_BASE_URL . 'assets/css/style.css', array(), MEDILAC_CORE_VERSION );
    
    
    
    
    //owl-carousel js
    //wp_enqueue_script( 'medilac-plugin', MEDILAC_CORE_BASE_URL . 'assets/js/script.js', array('jquery'), MEDILAC_CORE_VERSION, true );
    
    
    //medilac-core js
    wp_enqueue_script( 'medilac-plugin', MEDILAC_CORE_BASE_URL . 'assets/js/script.js', array('jquery'), MEDILAC_CORE_VERSION, true );
    
}
add_action( 'wp_enqueue_scripts', 'medilac_core_enqueue' );
<?php
function medilac_register_department_post_type() {

        $icon = MEDILAC_CORE_BASE_URL . 'assets/icons/department.svg';
	/**
	 * Post Type: Departments.
	 */

	$labels = [
		"name" => __( "Departments", "medilac" ),
		"singular_name" => __( "Department", "medilac" ),
		"menu_name" => __( "Departments", "medilac" ),
		"all_items" => __( "All Departments", "medilac" ),
		"add_new" => __( "Add new", "medilac" ),
		"add_new_item" => __( "Add new Department", "medilac" ),
		"edit_item" => __( "Edit Department", "medilac" ),
		"new_item" => __( "New Department", "medilac" ),
		"view_item" => __( "View Department", "medilac" ),
		"view_items" => __( "View Departments", "medilac" ),
		"search_items" => __( "Search Departments", "medilac" ),
		"not_found" => __( "No Departments found", "medilac" ),
		"not_found_in_trash" => __( "No Departments found in trash", "medilac" ),
		"parent" => __( "Parent Department:", "medilac" ),
		"featured_image" => __( "Featured image for this Department", "medilac" ),
		"set_featured_image" => __( "Set featured image for this Department", "medilac" ),
		"remove_featured_image" => __( "Remove featured image for this Department", "medilac" ),
		"use_featured_image" => __( "Use as featured image for this Department", "medilac" ),
		"archives" => __( "Department archives", "medilac" ),
		"insert_into_item" => __( "Insert into Department", "medilac" ),
		"uploaded_to_this_item" => __( "Upload to this Department", "medilac" ),
		"filter_items_list" => __( "Filter Departments list", "medilac" ),
		"items_list_navigation" => __( "Departments list navigation", "medilac" ),
		"items_list" => __( "Departments list", "medilac" ),
		"attributes" => __( "Departments attributes", "medilac" ),
		"name_admin_bar" => __( "Department", "medilac" ),
		"item_published" => __( "Department published", "medilac" ),
		"item_published_privately" => __( "Department published privately.", "medilac" ),
		"item_reverted_to_draft" => __( "Department reverted to draft.", "medilac" ),
		"item_scheduled" => __( "Department scheduled", "medilac" ),
		"item_updated" => __( "Department updated.", "medilac" ),
		"parent_item_colon" => __( "Parent Department:", "medilac" ),
	];

	$args = [
		"label" => __( "Departments", "medilac" ),
		"labels" => $labels,
		"description" => __( "This post type is for department custom post type.", "medilac" ),
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "department", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => $icon,//"dashicons-hammer",
		"supports" => [ "title", "editor", "thumbnail", "excerpt" ],
	];

	register_post_type( "medilac_department", $args );
}

add_action( 'init', 'medilac_register_department_post_type' );

function medilac_register_medilac_doctor_post_type() {
        $icon = MEDILAC_CORE_BASE_URL . 'assets/icons/team.svg';
	/**
	 * Post Type: Doctors.
	 */

	$labels = [
		"name" => __( "Doctors", "medilac" ),
		"singular_name" => __( "Doctor", "medilac" ),
		"menu_name" => __( "Our Doctors", "medilac" ),
		"all_items" => __( "All Doctors", "medilac" ),
		"add_new" => __( "Add new", "medilac" ),
		"add_new_item" => __( "Add new Doctor", "medilac" ),
		"edit_item" => __( "Edit Doctor", "medilac" ),
		"new_item" => __( "New Doctor", "medilac" ),
		"view_item" => __( "View Doctor", "medilac" ),
		"view_items" => __( "View Doctors", "medilac" ),
		"search_items" => __( "Search Doctors", "medilac" ),
		"not_found" => __( "No Doctors found", "medilac" ),
		"not_found_in_trash" => __( "No Doctors found in trash", "medilac" ),
		"parent" => __( "Parent Doctor:", "medilac" ),
		"featured_image" => __( "Featured image for this Doctor", "medilac" ),
		"set_featured_image" => __( "Set featured image for this Doctor", "medilac" ),
		"remove_featured_image" => __( "Remove featured image for this Doctor", "medilac" ),
		"use_featured_image" => __( "Use as featured image for this Doctor", "medilac" ),
		"archives" => __( "Doctor archives", "medilac" ),
		"insert_into_item" => __( "Insert into Doctor", "medilac" ),
		"uploaded_to_this_item" => __( "Upload to this Doctor", "medilac" ),
		"filter_items_list" => __( "Filter Doctors list", "medilac" ),
		"items_list_navigation" => __( "Doctors list navigation", "medilac" ),
		"items_list" => __( "Doctors list", "medilac" ),
		"attributes" => __( "Doctors attributes", "medilac" ),
		"name_admin_bar" => __( "Doctor", "medilac" ),
		"item_published" => __( "Doctor published", "medilac" ),
		"item_published_privately" => __( "Doctor published privately.", "medilac" ),
		"item_reverted_to_draft" => __( "Doctor reverted to draft.", "medilac" ),
		"item_scheduled" => __( "Doctor scheduled", "medilac" ),
		"item_updated" => __( "Doctor updated.", "medilac" ),
		"parent_item_colon" => __( "Parent Doctor:", "medilac" ),
	];

	$args = [
		"label" => __( "Doctors", "medilac" ),
		"labels" => $labels,
		"description" => __( "Use this custom post type for create your shining doctor doctors.", "medilac" ),
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "doctor", "with_front" => false ],
		"query_var" => true,
		"menu_icon" => $icon,//"dashicons-groups",
		"supports" => [ "title", "editor", "thumbnail" ],
	];

	register_post_type( "medilac_doctor", $args );
}

add_action( 'init', 'medilac_register_medilac_doctor_post_type' );

function medilac_register_medilac_case_post_type() {
        $icon = MEDILAC_CORE_BASE_URL . 'assets/icons/case.svg';
	/**
	 * Post Type: Case.
	 */

	$labels = [
		"name" => __( "Cases", "medilac" ),
		"singular_name" => __( "Case", "medilac" ),
		"menu_name" => __( "Case", "medilac" ),
		"all_items" => __( "All Cases", "medilac" ),
		"add_new" => __( "Add new", "medilac" ),
		"add_new_item" => __( "Add new Case", "medilac" ),
		"edit_item" => __( "Edit Case", "medilac" ),
		"new_item" => __( "New Case", "medilac" ),
		"view_item" => __( "View Case", "medilac" ),
		"view_items" => __( "View Cases", "medilac" ),
		"search_items" => __( "Search Cases", "medilac" ),
		"not_found" => __( "No Case found", "medilac" ),
		"not_found_in_trash" => __( "No Case found in trash", "medilac" ),
		"parent" => __( "Parent Case:", "medilac" ),
		"featured_image" => __( "Featured image for this Case", "medilac" ),
		"set_featured_image" => __( "Set featured image for this Case", "medilac" ),
		"remove_featured_image" => __( "Remove featured image for this Case", "medilac" ),
		"use_featured_image" => __( "Use as featured image for this Case", "medilac" ),
		"archives" => __( "Case archives", "medilac" ),
		"insert_into_item" => __( "Insert into Case", "medilac" ),
		"uploaded_to_this_item" => __( "Upload to this Case", "medilac" ),
		"filter_items_list" => __( "Filter Case list", "medilac" ),
		"items_list_navigation" => __( "Case list navigation", "medilac" ),
		"items_list" => __( "Cases list", "medilac" ),
		"attributes" => __( "Cases attributes", "medilac" ),
		"name_admin_bar" => __( "Case", "medilac" ),
		"item_published" => __( "Case published", "medilac" ),
		"item_published_privately" => __( "Case published privately.", "medilac" ),
		"item_reverted_to_draft" => __( "Case reverted to draft.", "medilac" ),
		"item_scheduled" => __( "Case scheduled", "medilac" ),
		"item_updated" => __( "Case updated.", "medilac" ),
		"parent_item_colon" => __( "Parent Case:", "medilac" ),
	];

	$args = [
		"label" => __( "Case", "medilac" ),
		"labels" => $labels,
		"description" => __( "Use this custom post type to tell the world about your cases.", "medilac" ),
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "case", "with_front" => false ],
		"query_var" => true,
		"menu_icon" => $icon,//"dashicons-images-alt",
		"supports" => [ "title", "editor", "thumbnail", "excerpt" ],
	];

	register_post_type( "medilac_case", $args );
}

add_action( 'init', 'medilac_register_medilac_case_post_type' );

/**
 * Add Custom Meta Boxes for Department Post Type
 *  
 *
 * @link https://github.com/CMB2/CMB2/wiki/Basic-Usage
 *
 * @package Medilac-core
 * @since 1.0.0.2
 */
add_action( 'cmb2_admin_init', 'medilac_core_departments_cmb2' );

if( !function_exists( 'medilac_core_departments_cmb2' ) ){
    function medilac_core_departments_cmb2(){
        
        /**
         * Department Information
         */
        $cmb = new_cmb2_box( array(
                'id'            => 'medilac_core_department_info',
                'title'         => __( 'Department Information', 'medilac' ),
                'object_types'  => array( 'medilac_department' ), // Post type
                'context'       => 'normal',
                'priority'      => 'high',
                'show_names'    => true, // Show field names on the left
                'closed'     => true, // Keep the metabox closed by default
        ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Sub Heading', 'medilac' ),
                    'desc'       => __( 'Type sub heading for this department', 'medilac' ),
                    'id'         => 'sub_heading',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                    
            ) );
        
        $department_faq = $cmb->add_field( array(
                'name'        => __( 'Add FAQs', 'medilac' ),
		'id'          => 'department_faq_group',
		'type'        => 'group',
		'options'     => array(
			'group_title'    => esc_html__( 'FAQ {#}', 'medilac' ), // {#} gets replaced by row number
			'add_button'     => esc_html__( 'Add Another FAQ', 'medilac' ),
			'remove_button'  => esc_html__( 'Remove FAQ', 'medilac' ),
			'sortable'       => true,
		),
	) );
        
        $cmb->add_group_field( $department_faq, array(
		'name'       => esc_html__( 'FAQ Title', 'medilac' ),
		'id'         => 'title',
		'type'       => 'text',
	) );

	$cmb->add_group_field( $department_faq, array(
		'name'        => esc_html__( 'FAQ Answer', 'medilac' ),
		'id'          => 'description',
		'type'        => 'textarea_small',
	) );
            
    }
}

/**
 * Added Custom Meta Boxes for medilac_doctor Post Type
 *  
 *
 * @link https://github.com/CMB2/CMB2/wiki/Basic-Usage
 *
 * @package Medilac-core
 * @since 1.0.0.2
 */
add_action( 'cmb2_admin_init', 'medilac_core_doctors_cmb2' );

if( !function_exists( 'medilac_core_doctors_cmb2' ) ){
    function medilac_core_doctors_cmb2(){
        
        /**
         * Doctor Information
         */
        $cmb = new_cmb2_box( array(
                'id'            => 'medilac_core_doctor_info',
                'title'         => __( 'Doctor Information', 'medilac' ),
                'object_types'  => array( 'medilac_doctor' ), // Post type
                'context'       => 'normal',
                'priority'      => 'high',
                'show_names'    => true, // Show field names on the left
                'closed'     => false, // Keep the metabox closed by default
        ) );
        
        $elementor_templates = medilac_core_elementor_template_choises();
        $cmb->add_field( array(
                'name'       => __( 'Bottom Part Template', 'medilac' ),
                'desc'       => __( 'Elementor is required. Select Footer part from Elementor Template. If not created, Create first.', 'medilac' ),
                'id'         => 'doctor_bottom_template',
                'type'       => 'select',
                'default'    => '',
                'sanitization_cb' => 'sanitize_text_field',
                'options'    => $elementor_templates,

        ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Sub Heading', 'medilac' ),
                    'desc'       => __( 'Type sub heading for this doctor', 'medilac' ),
                    'id'         => 'sub_heading',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
            ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Doctor Details', 'medilac' ),
                    'id'         => 'doctor_details',
                    'type'       => 'textarea_small',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field', 
            ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Appointment Button Text', 'medilac' ),
                    'id'         => 'doctor_appoint_text',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        $cmb->add_field( array(
                    'name'       => __( 'Appointment Link', 'medilac' ),
                    'id'         => 'doctor_appoint_link',
                    'type'       => 'text_url',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Phone Number', 'medilac' ),
                    'id'         => 'doctor_phone',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        
        $cmb->add_field( array(
                    'name'       => __( 'Email', 'medilac' ),
                    'id'         => 'doctor_email',
                    'type'       => 'text_email',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_email',
                
                    
            ) );
        $cmb->add_field( array(
                    'name'       => __( 'Address', 'medilac' ),
                    'id'         => 'doctor_address',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        
        $social_links = $cmb->add_field( array(
                'name'        => __( 'Social Links', 'medilac' ),
		'id'          => 'doctor_social_profile',
		'type'        => 'group',
		'options'     => array(
			'group_title'    => esc_html__( 'Link {#}', 'medilac' ), // {#} gets replaced by row number
			'add_button'     => esc_html__( 'Add Another', 'medilac' ),
			'remove_button'  => esc_html__( 'Remove', 'medilac' ),
			'sortable'       => true,
		),
	) );
        
        $cmb->add_group_field( $social_links, array(
		'name'       => __( 'Select one', 'medilac' ),
		'id'         => 'social_icon',
		'type'       => 'select',
                'show_option_none' => true,
                'default'          => 'la-facebook-f',
                'options'          => array(
                        'fa-facebook-f'     => __( 'Facebook', 'medilac' ),
                        'fa-twitter'        => __( 'Twitter', 'medilac' ),
                        'fa-linkedin-in'    => __( 'LinkenIn', 'medilac' ),
                        'fa-pinterest-p'    => __( 'Pinterest', 'medilac' ),
                ),  
	) );

	$cmb->add_group_field( $social_links, array(
		'name'        => __( 'Profile Link', 'medilac' ),
		'id'          => 'profile_link',
                'desc'        => __( 'Paste your social link here', 'medilac' ),
		'type'        => 'text_url',
	) );
                
        /**
         * Doctor Skills
         */
        $cmb2 = new_cmb2_box( array(
                'id'            => 'medilac_core_doctor_skill',
                'title'         => __( 'Doctor Skills', 'medilac' ),
                'object_types'  => array( 'medilac_doctor' ), // Post type
                'context'       => 'normal',
                'priority'      => 'high',
                'show_names'    => true, // Show field names on the left
                'closed'     => true, // Keep the metabox closed by default
        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Skill Sub Heading', 'medilac' ),
                    'id'         => 'skill_sub_heading',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Skill Heading', 'medilac' ),
                    'id'         => 'skill_heading',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
                
                    
            ) );
        
        $cmb2_skills = $cmb2->add_field( array(
                'name'        => __( 'Doctor Skills', 'medilac' ),
		'id'          => 'doctor_skills',
		'type'        => 'group',
		'options'     => array(
			'group_title'    => esc_html__( 'Skill {#}', 'medilac' ), // {#} gets replaced by row number
			'add_button'     => esc_html__( 'Add Another', 'medilac' ),
			'remove_button'  => esc_html__( 'Remove', 'medilac' ),
			'sortable'       => true,
		),
	) );
        
        $cmb2->add_group_field( $cmb2_skills, array(
		'name'        => __( 'Skill Name', 'medilac' ),
		'id'          => 'skill_name',
		'type'        => 'text',
                'sanitization_cb' => 'sanitize_text_field',
	) );
        
        $cmb2->add_group_field( $cmb2_skills, array(
		'name'        => __( 'Skill Level', 'medilac' ),
		'id'          => 'skill_level',
		'desc'        => __( 'Type skill level (in percent 0 to 100)', 'medilac' ),
		'type'        => 'text',
                'sanitization_cb' => 'sanitize_text_field',
	) );
        
        $cmb2->add_group_field( $cmb2_skills, array(
		'name'        => __( 'Skill Color', 'medilac' ),
		'id'          => 'skill_color',
		'desc'        => __( 'Select skill color to highlight', 'medilac' ),
		'type'        => 'colorpicker',
                'options' => array(
                    'alpha' => true, // Make this a rgba color picker.
                ),
	) );
            
    }
}

/**
 * Added Custom Meta Boxes for medilac_case Post Type
 *  
 *
 * @link https://github.com/CMB2/CMB2/wiki/Basic-Usage
 *
 * @package Medilac-core
 * @since 1.0.0.2
 */
add_action( 'cmb2_admin_init', 'medilac_core_case_cmb2' );

if( !function_exists( 'medilac_core_case_cmb2' ) ){
    function medilac_core_case_cmb2(){
        /**
         * Doctor Skills
         */
        $cmb2 = new_cmb2_box( array(
                'id'            => 'medilac_core_case_info',
                'title'         => __( 'Case Information', 'medilac' ),
                'object_types'  => array( 'medilac_case' ), // Post type
                'context'       => 'normal',
                'priority'      => 'high',
                'show_names'    => true, // Show field names on the left
                'closed'     => true, // Keep the metabox closed by default
        ) );
        
        $elementor_templates = medilac_core_elementor_template_choises();
        $cmb2->add_field( array(
                'name'       => __( 'Bottom Part Template', 'medilac' ),
                'desc'       => __( 'Elementor is required. Select Footer part from Elementor Template. If not created, Create first.', 'medilac' ),
                'id'         => 'case_bottom_template',
                'type'       => 'select',
                'default'    => '',
                'sanitization_cb' => 'sanitize_text_field',
                'options'    => $elementor_templates,

        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Case Name', 'medilac' ),
                    'id'         => 'case_name',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Patient\'s Name', 'medilac' ),
                    'id'         => 'patient_name',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Date', 'medilac' ),
                    'id'         => 'admission_date',
                    'type'       => 'text_date',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Address', 'medilac' ),
                    'id'         => 'patient_address',
                    'type'       => 'text',
                    'default'    => '',
                    'sanitization_cb' => 'sanitize_text_field',
        ) );
        
        $cmb2->add_field( array(
                    'name'       => __( 'Case Details', 'medilac' ),
                    'id'         => 'case_details',
                    'type'       => 'wysiwyg',
                    'default'    => '',
                    'sanitization_cb' => 'wp_kses_post',
        ) );
    }
}
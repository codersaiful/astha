<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Testimonial_Box extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_testimonial_box';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Testimonial Box', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Testimonial_Box';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'medilac eicon-testimonial';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'testimonial', 'review', 'feedback', 'user', 'rating' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'basic' ];
    }
    
    /**
     * Retrieve the list of scripts the counter widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0.13
     * @access public
     *
     * @return array Widget scripts dependencies.
     * @by Saiful
     */
    public function get_script_depends() {
            return [ 'jquery', 'swiper' ];
    }
    
    /**
     * Totally new Created
     * We will use this format to Add
     * Additional JS Library
     * for our Element/Widget
     * 
     * @return Array
     */
    public function medilac_settings(){
        //return; //On Apply, need to comment out this line
        return [
//            'additional_scripts'       => [
//                'swiper-min' =>    [
//                    'url'               =>  MEDILAC_CORE_BASE_URL . '/assets/vendor/js/swiper-min.js',
//                    'dependency'        =>  ['jquery'],
//                    'version'           => false,
//                    'in_footer'         =>  true,
//                ],
//            ],
            'dependency'       =>  ['jquery','swiper'],
            'version'       =>  '1.0.0.12',
            'in_footer'     =>  true,
        ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        

        //For General Section
        $this->content_general_controls();

        //For Design Section Style Tab
        $this->style_general_controls();
        
        //Section in Style Tab
        $this->style_title_controls();
        $this->style_subtitle_controls();
        $this->style_quote_controls();
        $this->style_avatar_controls();

       
    }
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute( 'wrapper', 'class', 'mc-testimonial-wrapper' );
        $this->add_render_attribute( 'item', 'class', 'mc-testimonial' );
        $this->add_render_attribute( 'title', 'class', 'mc-testimonial-title' );
        $this->add_render_attribute( 'sub-title', 'class', 'mc-testimonial-subtitle' );
        $this->add_render_attribute( 'quote', 'class', 'mc-testimonial-quote' );
        
        $this->add_inline_editing_attributes( 'title', 'none' );
        $this->add_inline_editing_attributes( 'sub-title', 'none' );
        $this->add_inline_editing_attributes( 'quote', 'advanced' );

        $image = !empty( $settings['image']['url'] ) ? $settings['image']['url'] : false;
        if( empty( $image ) ){
            $this->add_render_attribute( 'wrapper', 'class', 'no-profile-image' );
        }
        ?>
    <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
        <div <?php echo $this->get_render_attribute_string( 'item' ); ?>>
            <div class="client-quote-box">
                <span class="quote-icon">
                    <i class="fas fa-quote-left"></i>
                </span>
                <?php echo '<p ' . $this->get_render_attribute_string( 'quote' ) . '>' . $settings['quote'] . '</p>'; ?>
                <div class="client-info">
                    <div class="user-avatar" 
                        <?php if( $image ){ ?>
                            style="background-image: url(<?php echo esc_attr( $image ); ?>);"
                        <?php } ?> 
                         ></div>
                    <div class="user-name">
                        <?php echo '<p ' . $this->get_render_attribute_string( 'title' ) . '>' . $settings['title'] . '</p>'; ?>
                        <?php echo '<span ' . $this->get_render_attribute_string( 'sub-title' ) . '>' . $settings['sub-title'] . '</span>'; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
        <?php
        
    }
    
    protected function _content_template() {
        /*
        ?>
        <#
        view.addInlineEditingAttributes( 'avd_heading', 'none' );
        view.addInlineEditingAttributes( 'avd_sub_heading', 'none' );
        #>
        
        <div class="advance-heading-wrapper">
            <span {{{ view.getRenderAttributeString( 'avd_sub_heading' ) }}}>{{{ settings.avd_sub_heading }}}</span>
            <h4 class="heading-tag" {{{ view.getRenderAttributeString( 'avd_heading' ) }}}>{{{ settings.avd_heading }}}</h4>
        </div>
        <?php
        */
    }
    
    /**
     * General Section for Content Controls
     * 
     * @since 1.0.0.9
     */
    protected function content_general_controls() {
        
        $placeholder_image = MEDILAC_CORE_BASE_URL . 'assets/images/user.png';
        
        $this->start_controls_section(
            'general_content',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
                'tab'       => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        
        $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'medilac' ),
                    'type' => Controls_Manager::TEXT,
                    'default'       => __( 'Jonny Robartson', 'medilac' ),
                    'label_block'   => TRUE,
                    'dynamic'       => ['active' => true],
                ]
        );
        
        $this->add_control(
                'sub-title',
                [
                    'label' => __( 'Position/Designation', 'medilac' ),
                    'type' => Controls_Manager::TEXT,
                    'default'       => __( 'UI/UX Designer', 'medilac' ),
                    'label_block'   => TRUE,
                    'dynamic'       => ['active' => true],
                ]
        );
        
        $this->add_control(
                'quote',
                [
                    'label' => __( 'Quote', 'medilac' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default'       => __( 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incdidunt ut labore et dolore magna do aliqua quis ipsum suspendisse ces gravida. Risus commodo viverra maecenas.', 'medilac' ),
                    'label_block'   => TRUE,
                    'dynamic'       => ['active' => true],
                    'rows' => 5,
                    'separator' => 'after',
                ]
        );
        
        $this->add_control(
                'image',
                [
                        'label' => __( 'Photo', 'medilac' ),
                        'type' => Controls_Manager::MEDIA,
                        'default' => [
                                'url' => $placeholder_image,//Utils::get_placeholder_image_src(),
                        ],
                        'dynamic' => [
                                'active' => true,
                        ]
                ]
        );
        
               
        
        $this->end_controls_section();
    }
    
    /**
     * Alignment Section for Style Tab
     * 
     * @since 1.0.0.9
     */
    protected function style_general_controls() {
        $this->start_controls_section(
            'style_general',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
                'text_align',
                [
                        'label' => __( 'Alignment', 'medilac' ),
                        'type' => \Elementor\Controls_Manager::CHOOSE,
                        'options' => [
                                'left' => [
                                        'title' => __( 'Left', 'medilac' ),
                                        'icon' => 'fa fa-align-left',
                                ],
                                'center' => [
                                        'title' => __( 'Center', 'medilac' ),
                                        'icon' => 'fa fa-align-center',
                                ],
                                'right' => [
                                        'title' => __( 'Right', 'medilac' ),
                                        'icon' => 'fa fa-align-right',
                                ],
                        ],
                        'default' => 'center',
                        'toggle' => true,
                        'prefix_class' => 'elementor-align-',
                        'default' => 'left',
                ]
        );
        
        
        $this->start_controls_tabs('testimonial-style-tabs');
        $this->start_controls_tab('testimonial-stl-tab-normal', 
                [
                    'label' => __( 'Normal', 'medilac' ),
                ]
        );
        
        
        
        $this->add_control(
                'quote_icon_color',
                [
                        'label' => __( 'Quote Icon Color', 'medilac' ),
                        'type' => Controls_Manager::COLOR,
                        'default' => '#0FC392',
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box span.quote-icon' => 'color: {{VALUE}}',
                        ],
                ]
        );
        
        
        
        
        $this->end_controls_tab();
        
        $this->start_controls_tab('testimonial-stl-tab-hover', 
                [
                    'label' => __( 'Hover', 'medilac' ),
                ]
        );
        
        $this->add_control(
                'quote_icon_color_hover',
                [
                        'label' => __( 'Quote Icon Color', 'medilac' ),
                        'type' => Controls_Manager::COLOR,
                        'selectors' => [
                                '{{WRAPPER}}:hover .mc-testimonial-wrapper .client-quote-box span.quote-icon' => 'color: {{VALUE}}',
                        ],
                ]
        );
        
        $this->end_controls_tab();
        
        
        
        
        
        
        
        
        $this->end_controls_tabs();
        
        
        
        
        
        
        $this->add_control(
                'quote-icon-size',
                [
                        'label' => __( 'Quote Icon Size', 'medilac' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                                'px' => [
                                        'min' => 0,
                                        'max' => 100,
                                        'step' => 1,
                                ],
                                '%' => [
                                        'min' => 0,
                                        'max' => 100,
                                ],
                        ],
                        'default' => [
                                'unit' => 'px',
                                'size' => 50,
                        ],
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box span.quote-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                        ],
                ]
        );
        
        
       
        $this->end_controls_section();
    }
    
    /**
     * Section for Title in Style Tab
     * 
     * @since 1.0.0.15
     */
    protected function style_title_controls() {
        $this->start_controls_section(
            'title-typography',
            [
                'label'     => esc_html__( 'Title', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        
        
        $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                        'name' => 'title_typography',
                        'label' => 'Title Typography',
                        'selector' => '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-title',
                ]
        );
        
        $this->add_control(
                'title_color',
                [
                        'label' => __( 'Color', 'medilac' ),
                        'type' => Controls_Manager::COLOR,
                        'default' => '#5C6B79',
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-title' => 'color: {{VALUE}}',
                        ],
                ]
        );
        
        
        $this->end_controls_section();
    }
    
    /**
     * Section for Sub Title in Style Tab
     * 
     * @since 1.0.0.15
     */
    protected function style_subtitle_controls() {
        $this->start_controls_section(
            'subtitle-typography',
            [
                'label'     => esc_html__( 'Position', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        
        
        $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                        'name' => 'position_typography',
                        'label' => 'Position Typography',
                        'selector' => '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-subtitle',
                ]
        );
        
        $this->add_control(
                'subtitle_color',
                [
                        'label' => __( 'Color', 'medilac' ),
                        'type' => Controls_Manager::COLOR,
                        'default' => '#5C6B79',
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-subtitle' => 'color: {{VALUE}}',
                        ],
                ]
        );
        
        
        $this->end_controls_section();
    }
    
    /**
     * Section for Quote in Style Tab
     * 
     * @since 1.0.0.15
     */
    protected function style_quote_controls() {
        $this->start_controls_section(
            'quote-typography',
            [
                'label'     => esc_html__( 'Quote', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        
        
        $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                        'name' => 'quote_typography',
                        'label' => 'Quote Typography',
                        'selector' => '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-quote',
                ]
        );
        
        $this->add_control(
                'quote_color',
                [
                        'label' => __( 'Color', 'medilac' ),
                        'type' => Controls_Manager::COLOR,
                        'default' => '#54595F',
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-quote-box .mc-testimonial-quote' => 'color: {{VALUE}}',
                        ],
                ]
        );
        
        
        $this->end_controls_section();
    }
    
    /**
     * Section for Quote in Style Tab
     * 
     * @since 1.0.0.15
     */
    protected function style_avatar_controls() {
        $this->start_controls_section(
            'avatar',
            [
                'label'     => esc_html__( 'Avatar', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'avatar-border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .mc-testimonial-wrapper .client-info .user-avatar',
            )
        );
        
        $this->add_control(
                'avatar-size',
                [
                        'label' => __( 'Size', 'medilac' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', '%' ],
                        'range' => [
                                'px' => [
                                        'min' => 0,
                                        'max' => 100,
                                        'step' => 1,
                                ],
                                '%' => [
                                        'min' => 0,
                                        'max' => 100,
                                ],
                        ],
                        'default' => [
                                'unit' => 'px',
                                'size' => 50,
                        ],
                        'selectors' => [
                                '{{WRAPPER}} .mc-testimonial-wrapper .client-info .user-avatar' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                        ],
                ]
        );
        
        
        $this->end_controls_section();
    }
       
    
}
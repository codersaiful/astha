<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Counter extends Widget_Base{
    
    /**
     * Widget Counter
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_counter';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Counter Up', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Counter';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-counter';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'counter', 'counterup', 'countdown' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Icon or Image
        $this->register_icon_image();
        // Counter Value style
        $this->register_counter_value();
        // Counter After Symbol
        $this->register_after_symbol();
        // Counter Text
        $this->register_text_symbol();
    }
    
    /**
     * Register Price Table General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'counter_item',
            [
                'label'     => esc_html__( 'Counter', 'medilac' ),
            ]
        );
        $this->add_control(
            'icon_style',
            [
                'label'     => esc_html__( 'Select Icon Or Image', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'icon'      => __( 'Icon', 'medilac' ),
                    'image'     => __( 'Image', 'medilac')
                ],
                'default'       => 'icon',
                
            ]
        );
        $this->add_control(
            'add_icon',
                [
                        'label'     => __( 'Icon', 'medilac' ),
                        'type'      => Controls_Manager::ICONS,
                        'default'   => [
                                'value' => 'fas fa-star',
                                'library' => 'solid',
                        ],
                    'condition' => [
                        'icon_style'    => 'icon',
                    ]
                ]
        );
        $this->add_control(
            'add_image',
            [
                'label'     => __( 'Select Image', 'medilac' ),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'icon_style'    => 'image',
                ]
            ]
        );
        $this->add_control(
            'counter_value',
            [
                'label'         => esc_html__( 'Countrer Value', 'medilac' ),
                'type'          => Controls_Manager::NUMBER,
                'description'   => esc_html__( 'Type here your value here', 'medilac' ),
                'default'       => '2500',
            ]
        );
        $this->add_control(
            'counter_after_symbol',
            [
                'label'         => esc_html__( 'Counter Befter Symbol', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => '+',
            ]
        );
        $this->add_control(
            'counter_title',
            [
                'label'         => esc_html__( 'Counter Title', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => 'Good Products',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get Icon Or Image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_icon_image(){
	    $this->start_controls_section(
	            'counter_icon',
                [
                    'label'     => esc_html__( 'Icon or Image', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'icon_text_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'condition' => [
                    'icon_style'    => array('icon')
                ],
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'counter_icon_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'counter_icon_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img',
            )
        );
        $this->add_responsive_control(
            'regular_price_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_item_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_border_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'counter_shadow_box',
                'selector' => '{{WRAPPER}} .counter-item.medilac-counter .counter-icon span i, .counter-item.medilac-counter .counter-icon span img',
            )
        );
	$this->end_controls_section();
    }
    
    /**
     * Counter Value
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_counter_value(){
	$this->start_controls_section(
	            'counter_value_settings',
                [
                    'label'     => esc_html__( 'Counter Value', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'counter_value_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'counter_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'counter_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'counter_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6',
            )
        );
        $this->add_responsive_control(
            'counter_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'counter_shadow_control',
                'selector' => '{{WRAPPER}} .counter-item.medilac-counter .counter-text h6',
            )
        );
	$this->end_controls_section();
        
    }
   
    /**
     * Counter After Symbol
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_after_symbol(){
	$this->start_controls_section(
	            'counter_symbol',
                [
                    'label'     => esc_html__( 'Counter After Symbol', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'counter_value_after_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text span' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'counter_contents_after_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'counter_after_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .counter-item.medilac-counter .counter-text span',
            )
        );
        $this->add_responsive_control(
            'counter_after_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_content_after_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_span_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'counter_span_shadow',
                'selector' => '{{WRAPPER}} .counter-item.medilac-counter .counter-text span',
            )
        );
	$this->end_controls_section();
    }
    
    /**
     * Count Down Text
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_text_symbol(){
	$this->start_controls_section(
	            'counter_text_style',
                [
                    'label'     => esc_html__( 'Counter Text', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'counter_value_text_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text p' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'counter_contents_text_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'counter_text_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .counter-item.medilac-counter .counter-text p',
            )
        );
        $this->add_responsive_control(
            'counter_text_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_content_text_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_text_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .counter-item.medilac-counter .counter-text p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'counter_text_shadow',
                'selector' => '{{WRAPPER}} .counter-item.medilac-counter .counter-text p',
            )
        );
	$this->end_controls_section();
        
    }

    /**
     * Get Image Icon.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function get_image_icon(){
        $settings   = $this->get_settings_for_display();
        $icon_style = isset( $settings['icon_style'] ) ? $settings['icon_style'] : 'icon';
        $add_image  = isset( $settings['add_image']['url'] ) ? $settings['add_image']['url'] : '';
        $add_icon   = !empty( $settings['add_icon']['value'] ) && is_string( $settings['add_icon']['value'] ) ? $settings['add_icon']['value'] : false;
        $svg        = !empty( $settings['add_icon']['value']['url'] ) && is_string( $settings['add_icon']['value']['url'] ) ? $settings['add_icon']['value']['url'] : false;

        if( 'image' == $icon_style ){?>
            <div class="counter-icon">
                <span>
                     <img class="pricing_table_image" src="<?php echo esc_url( $add_image );?>" alt="<?php esc_attr__( 'Pricing Image', 'medilac' ); ?>">
                </span>
            </div>
            <?php }elseif( $add_icon ){ ?>
            <div class="counter-icon">
                <span>
                     <i class="pricing_table_icon <?php echo esc_attr( $add_icon ); ?>"></i>   
                </span>
            </div>
            <?php }elseif( $svg ){ ?>
            <div class="counter-icon">
                <span>
                     <img class="pricing_table_image price-table-svg-image" src="<?php echo esc_url( $svg );?>" alt="<?php esc_attr__( 'Counter Image', 'medilac' ); ?>">
                </span>
            </div>
            
        <?php }
    }
    

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings       = $this->get_settings_for_display();
        $counter_value          = isset( $settings['counter_value'] ) ? $settings['counter_value'] : '';
        $counter_after_symbol   = isset( $settings['counter_after_symbol'] ) ? $settings['counter_after_symbol'] : '';
        $counter_title          = isset( $settings['counter_title'] ) ? $settings['counter_title'] : '';
        ?>
        <div class="counter-item medilac-counter">
            <?php $this->get_image_icon();?>
            <div class="counter-text">
                <?php if(!empty( $counter_value )) : ?>
                <h6 class="counter-value" data-from="0" data-to="<?php echo esc_attr( $counter_value );?>" data-speed="<?php echo esc_attr( $counter_value );?>"></h6>
                <span><?php echo esc_attr( $counter_after_symbol );?></span>
                <?php endif; ?>
                <?php if(!empty( $counter_title )) : ?>
                <p><?php echo esc_html( $counter_title ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php 
    }
    
    protected function _content_template() {}
    
}
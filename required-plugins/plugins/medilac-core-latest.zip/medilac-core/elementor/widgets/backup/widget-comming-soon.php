<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Comming_Soon extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_comming_soon';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Comming soon', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Comming_Soon';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-clock-o';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'commingsoon', 'comming'];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Register Timer Value style
        $this->register_countdown_timer_style();
        // Timer Name style
        $this->register_countdown_timer_name_style();
    }
    
    /**
     * Register Price Table General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'countdown_section_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'count_days', [
                'label'         => esc_html__( 'Select Days', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__('Type here numbercal value only', 'medilac'),
                'default'       => 25,
            ]
        );
        $this->add_control(
            'count_hours', [
                'label'         => esc_html__( 'Select Hours', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__('Type here numbercal value only', 'medilac'),
                'default'       => 24,
            ]
        );
        $this->add_control(
            'count_min', [
                'label'         => esc_html__( 'Select Minites', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__('Type here numbercal value only', 'medilac'),
                'default'       => 60,
            ]
        );
        $this->add_control(
            'count_sec', [
                'label'         => esc_html__( 'Select Seconds', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'description'   => esc_html__('Type here numbercal value only', 'medilac'),
                'default'       => 60,
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Register Counter value style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_countdown_timer_style(){
	    $this->start_controls_section(
	            'counter_value_style',
                [
                    'label'    => __( 'Countdown Value', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'counter_value_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'counter_timer_typography',
                'selector' => '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'counter_timer_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'counter_timer_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'counter_timer_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)',
            ]
        );
        $this->add_control(
            'counter_timer_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(1)' => 'text-align: {{VALUE}}',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * countdown timer name
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_countdown_timer_name_style(){
	    $this->start_controls_section(
	            'coudown_name_settings',
                [
                    'label'     => esc_html__( 'countdown Name', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'regular_pricing_content_normal', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'countdown_timer_name_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'countdown_timmner_name_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'countdown_timer_name_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)',
            )
        );
        $this->add_responsive_control(
            'countdown_timer_name_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_timer_name_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'counter_timer_nanme_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'counter_timer_name_shadow',
                'selector' => '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)',
            )
        );
        $this->add_control(
            'counter_timer_name_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} section.page-template-template-home4.scope-area.medilac-counter .scope-date-wrapper .single-date span:nth-child(2)' => 'text-align: {{value}};',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
	    $this->end_controls_section();
    }
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        $count_days = isset( $settings['count_days'] ) ? $settings['count_days'] : '';
        $count_hours = isset( $settings['count_hours'] ) ? $settings['count_hours'] : '';
        $count_min   = isset( $settings['count_min'] ) ? $settings['count_min'] : '';
        $count_sec   = isset( $settings['count_sec'] ) ? $settings['count_sec'] : '';
       ?>
        <!-- Stethoscope Area Start -->
        <section class="page-template-template-home4 scope-area medilac-counter">
          <div class="medilac-home-container">
            <div class="row">
              <div id="countdown" class="scope-date-wrapper">
                <div class="single-date"><span class="days">06 </span><span>Days</span></div>
                :
                <div class="single-date"><span class="hrs">10 </span><span>Hours</span></div>
                :
                <div class="single-date"><span class="mnts">56 </span><span>Minutes</span></div>
                :
                <div class="single-date"><span class="secs">30 </span><span>Seconds</span></div>
              </div>
            </div>
          </div>
        </section>
        <!-- Stethoscope Area End -->
        <script>
            ( function() {

                //Write your Pure JavaScript Code Here. I just added a console for test
                console.log("Pure/Core JavaScript");
                 //Start Coding Here

                // open social icon on click
                document.body.querySelectorAll(".page-template-template-home3 .social-links a:nth-child(1)").forEach(function (plus) {
                    plus.addEventListener("click", function (e) {
                        e.preventDefault();
                        plus.parentElement.classList.toggle("active");
                        plus.classList.toggle("rotated");
                    })
                })

                // Countdown for page 4
                function getTimeRemaining(endtime) {
                    const total = Date.parse(endtime) - Date.parse(new Date());
                    const seconds = Math.floor((total / 1000) % 60);
                    const minutes = Math.floor((total / 1000 / 60) % 60);
                    const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
                    const days = Math.floor(total / (1000 * 60 * 60 * 24));

                    return {
                        total,
                        days,
                        hours,
                        minutes,
                        seconds
                    };
                }

                function initializeClock(id, endtime) {
                    try{
                        const clock = document.getElementById(id);
                        const daysSpan = clock.querySelector('.days');
                        const hoursSpan = clock.querySelector('.hrs');
                        const minutesSpan = clock.querySelector('.mnts');
                        const secondsSpan = clock.querySelector('.secs');

                        function updateClock() {
                            const t = getTimeRemaining(endtime);

                            daysSpan.innerHTML = t.days;
                            hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                            minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                            secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

                            if (t.total <= 0) {
                                clearInterval(timeinterval);
                            }
                        }

                        updateClock();
                        const timeinterval = setInterval(updateClock, 1000);
                    }catch(e){
                        //e.getMessage();
                        return;
                    }
                }

                const deadline = new Date(Date.parse(new Date()) + <?php echo esc_attr( $count_days );?> * <?php echo esc_attr( $count_hours );?> * 60 * 60 * 1000);
                initializeClock('countdown', deadline);



            } )();

        </script>   
      <?php 
        
    }
    
    protected function _content_template() {}
    
}
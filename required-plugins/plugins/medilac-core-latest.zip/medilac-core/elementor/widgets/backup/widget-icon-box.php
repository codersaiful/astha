<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Icon_Box extends Widget_Base{
    
    /**
     * Widget Icon Box
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_icon_box';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Icon Box', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Icon_Box';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-icon-box';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'icon', 'box', 'iconbox' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Register Hover image settings
        $this->register_hover_image();
        // Register Pricing Image 
        $this->register_icon_box_image();
        // Register Icon Box Heading Controls.
        $this->register_heading_controls();
         // Register Price Controls.
        $this->register_icon_box_box_controls();
        // Register Ribbon
        $this->register_button_controls();
        // Icon Style
        $this->register_icon_style();
        // Heading Style
        $this->register_heading_style_controls();
        // Register Icon Box Content
        $this->register_icon_box_content_style();
        // Icon Box Button Style
        $this->register_cta_style_controls();
    }
    
    /**
     * Register Icon Box General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'icon_box_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'icon_box_style',
            [
                'label'     => esc_html__( 'Icon Box Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                    '3'         => esc_html__( 'Style 03', 'medilac' ),
                    '4'         => esc_html__( 'Style 04', 'medilac' ),
                    '5'         => esc_html__( 'Style 05', 'medilac' ),
                    '6'         => esc_html__( 'Style 06', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get Hover Image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_hover_image(){
        $this->start_controls_section(
            'widget_hover_box',
            [
                'label'     => esc_html__( 'Hover Image', 'medilac' ),
                'condition' => [
                    'icon_box_style'    => array('1')
                ]
            ]
        );
        $this->add_control(
            'hover_image',
            [
                'label'     => esc_html__( 'Add Hover Image', 'medilac' ),
                'type'      => Controls_Manager::MEDIA,
            ]
        );
        $this->end_controls_section();
    }
        
    /**
     * Get Image Or Icon
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_icon_box_image(){
        $this->start_controls_section(
            'widget_icon_box',
            [
                'label'     => esc_html__( 'Image or Icon', 'medilac' ),
            ]
        );
        $this->add_control(
            'icon_style',
            [
                'label'     => esc_html__( 'Select Icon Or Image', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'icon'      => __( 'Icon', 'medilac' ),
                    'image'     => __( 'Image', 'medilac')
                ],
                'default'       => 'image',
                
            ]
        );
        $this->add_control(
            'add_icon',
                [
                        'label'     => __( 'Icon', 'medilac' ),
                        'type'      => Controls_Manager::ICONS,
                        'default'   => [
                                'value' => 'fas fa-star',
                                'library' => 'solid',
                        ],
                    'condition' => [
                        'icon_style'    => 'icon',
                    ]
                ]
        );
        
        $this->add_control(
            'add_image',
            [
                'label'     => __( 'Select Image', 'medilac' ),
                'type'      => Controls_Manager::MEDIA,
                'condition' => [
                    'icon_style'    => 'image',
                ]
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Icon Box Heading Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_controls(){
        $this->start_controls_section(
                'section_header_settings',
            [
                    'label'     => esc_html__( 'Heading', 'medilac' ),
            ]
        );
        $this->add_control(
            'heading',
                [
                    'label'     => esc_html__( 'Heading', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'label_block'   => TRUE,
                    'default'       => 'Quality Guarantee',
                ]
        );
        
	$this->end_controls_section();
    }

    /**
     * Icon Box Content
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_icon_box_box_controls(){
        $this->start_controls_section(
            'icon_box_content',
            [
                'label'     => esc_html__( 'Icon Box Content', 'medilac' ),
                'condition'     => [
                     'icon_box_style!'    => array('6')
                ],
            ]
        );
        $this->add_control(
            'icon_box_text',
            [
                    'label'         => esc_html__( 'Content', 'medilac' ),
                    'type'          => Controls_Manager::TEXTAREA,
                    'label_block'   => true,
                    'default'       => 'Lorem ipsum dolor sitre ameta consecter adipiscing',
            ]
        );
        
        $this->end_controls_section();
    }

    /**
     *  Icon Box Button text
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_button_controls(){
	$this->start_controls_section(
            'widget_icon_box_btn',
            [
               'label'  => __( 'Button', 'medilac' ),
                'condition' => [
                    'icon_box_style!'    => ['4', '5', '6'],
                ]
            ]
        );
        $this->add_control(
            'text',
            [
                'label'     => esc_html__( 'Text', 'medilac' ),
                'type'      => Controls_Manager::TEXT,
                'label_block'   => TRUE,
                'default'   => __( 'Get started now', 'medilac' ),
                'pleaceholder'  => __( 'Get started now', 'medilac' ),
            ]
        );
        $this->add_control(
            'link',
            [
                'label'     => esc_html__( 'Link', 'medilac' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'medilac' ),
                'show_external' => true,
            ]
        );
	$this->end_controls_section();
    }
    
    /**
     * Register Icon Box Heading Style Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_style_controls(){
	    $this->start_controls_section(
	            'section_header_style',
                [
                    'label'    => __( 'Heading', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'heading_style',
            [
                'label'     => __( 'Title', 'medilac' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'heading_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .medilac-icon-box .service-info h2, .medilac-icon-box .promo-box-title h4, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_typography',
                'selector' => '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .pricing-box-item .pricing-icon .medilac-price-table-heading, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'header_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .pricing-box-item .pricing-icon .medilac-price-table-heading, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'header_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .pricing-box-item .pricing-icon .medilac-price-table-heading, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'heading_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .pricing-box-item .pricing-icon .medilac-price-table-heading, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title',
            ]
        );
        $this->add_control(
            'pricing_heading_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department p, .pricing-box-item .pricing-icon .medilac-price-table-heading, .page-template-template-home3 .promo-text .promo-title, .services-area .service-texts .service-title' => 'text-align: {{VALUE}}',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Price style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_icon_box_content_style(){
	    $this->start_controls_section(
	            'icon_box_contents_style',
                [
                    'label'     => esc_html__( 'Content', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'condition'     => [
                         'icon_box_style!'    => array('6')
                    ],
                ]

        );
        $this->add_control(
            'box_content_normal', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'icon_box_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_box_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'icon_box_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc',
            )
        );
        $this->add_responsive_control(
            'icon_box_content_padding_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_box_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_box_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'icon_box_shadow',
                'selector' => '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc',
            )
        );
        $this->add_control(
            'icon_box_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-icon-box .service-info p.para, .medilac-icon-box .promo-box-info p, .promo-box.promo-box-appointment .promo-desc, .services-area .service-texts .service-desc' => 'text-align: {{value}};',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
	    $this->end_controls_section();
    }
    
    /**
     * Price Sale Price Style.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_icon_style(){
	$this->start_controls_section(
            'icon_settings',
            [
                'label'     => esc_html__( 'Icon Settings', 'medilac' ),
                'tab'      => Controls_Manager::TAB_STYLE,
                'condition'  => [
                    'icon_style'    => array('icon'),
                ]
            ]
        );
        $this->add_control(
            'icon_color_content_normal', [
                'label'     => esc_html__( 'Icon Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'icon_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'icon_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i',
            )
        );
        $this->add_responsive_control(
            'icon_box_content_paddings',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'icon_shadow',
                'selector' => '{{WRAPPER}} .page-template-template-home3.medilac-icon-box .single-department i, .service-item.medilac-icon-box .service-icon.bg-green i, .promo-box.bg-black.medilac-icon-box .promo-box-title i, .service-item.medilac-icon-box .service-icon i, .promo-box.promo-box-appointment .promo-img i, .services-area .single-service i',
            )
        );
        
	$this->end_controls_section();
    }

    /**
     * Register Button style here.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_cta_style_controls() {

        $this->start_controls_section(
            'section_icon_box',
            [
                'label'      => __( 'Button', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
                'condition'     => [
                     'icon_box_style!'    => array('6', '4', '5')
                ],
            ]
        );
        $this->start_controls_tabs( 'icon_boxes_btn' );
        $this->start_controls_tab(
            'tab_button_content_normal',
            [
                'label'  => esc_html__( 'Normal', 'medilac' )
            ]
        );
        $this->add_control(
            'icon_boxes_btn_normal_', [
                'label'     => esc_html__( 'Content & Icon', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'icon_boxes_btn_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'icon_boxes_btn_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1',
            )
        );
        $this->add_responsive_control(
            'icon_boxes_btn_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_boxes_btn_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_boxes_btn_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'icon_b_shadow',
                'selector' => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1',
            )
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_boxes_btn_content_hover',
            [
                'label' => esc_html__( 'Hover', 'medilac' ),
            ]
        );
        $this->add_control(
            'button_label_hover',
            array(
                'label'       => esc_html__( 'Button Text & Icon', 'medilac' ),
                'type'        => Controls_Manager::COLOR,
                'selectors'	 => [
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover' => 'color: {{VALUE}};'
                ],
            )
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'icon_boxes_btn_hover_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'pricing_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover',
            )
        );
        $this->add_responsive_control(
            'hover_button_icon_boxes_btn_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'hover_button_icon_boxes_btn_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'icon_hover_border_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'hover_box_shadow',
                'selector' => '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1:hover',
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control(
            'icon_btn_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors'     => [
                    '{{WRAPPER}} .medilac-icon-box a.btn, .medilac-icon-box a.link, .medilac-icon-box a.link-v1' => 'text-align: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get Image Icon.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function get_image_icon(){
        $settings   = $this->get_settings_for_display();
        $icon_style = isset( $settings['icon_style'] ) ? $settings['icon_style'] : 'icon';
        $add_image  = isset( $settings['add_image']['url'] ) ? $settings['add_image']['url'] : '';
        $add_icon   = !empty( $settings['add_icon']['value'] ) && is_string( $settings['add_icon']['value'] ) ? $settings['add_icon']['value'] : false;
        $svg        = !empty( $settings['add_icon']['value']['url'] ) && is_string( $settings['add_icon']['value']['url'] ) ? $settings['add_icon']['value']['url'] : false;

        if( 'image' == $icon_style ){?>
        <img class="service-icon" src="<?php echo esc_url( $add_image );?>" alt="<?php esc_attr__( 'Icon Box', 'medilac' ); ?>">
        <?php }elseif( $add_icon ){ ?>
            <i class="service_icon <?php echo esc_attr( $add_icon ); ?>"></i>        
        <?php }elseif( $svg ){ ?>
            <img class="service-icon price-table-svg-image" src="<?php echo esc_url( $svg );?>" alt="<?php esc_attr__( 'Icon Box', 'medilac' ); ?>">
        <?php }
    }
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        $hover_image    = isset( $settings['hover_image'] ) ? $settings['hover_image'] : '';
        $heading    = isset( $settings['heading'] ) ? $settings['heading'] : '';
        $box_text   = isset( $settings['icon_box_text'] ) ? $settings['icon_box_text'] : '';
        $text               = isset( $settings['text'] ) ? $settings['text'] : '';
        $link              = isset( $settings['link']['url'] ) ? $settings['link']['url'] : '';
        $target             = $settings['link']['is_external'] ? ' target=_blank' : '';
        $nofollow           = $settings['link']['nofollow'] ? ' rel=nofollow' : '';
        if( isset( $settings['icon_box_style'] ) && '1' == $settings['icon_box_style'] ){?>
            <div class="service-item medilac-icon-box">
                <?php if(!empty( $hover_image['url'] )) : ?>
                <img src="<?php echo esc_url( $hover_image['url'] );?>" alt="<?php esc_attr_e('Image', 'medilac');?>" class="service-hover">
                <?php endif; ?>
                <div class="service-icon bg-green">
                    <?php $this->get_image_icon(); ?>
                </div>
                <div class="service-info">
                    <?php if(!empty( $heading )) : ?>
                    <h2><?php echo esc_html( $heading );?></h2>
                    <?php endif; ?>
                    <?php if(!empty( $box_text )) : ?>
                    <p class="para"><?php echo esc_html( $box_text );?></p>
                    <?php endif; ?>
                    <?php if( !empty( $text ) && !empty( $link ) ) : ?>
                    <a href="<?php echo esc_url( $link );?>" <?php echo esc_attr( $target );?> <?php echo esc_attr( $nofollow );?> class="btn v5"><?php echo esc_attr( $text ); ?> <i class="fas fa-angle-double-right"></i></a>
                    <?php endif; ?>
                </div>
            </div>   
        <?php }elseif('2' == $settings['icon_box_style']) {?>
            <div class="promo-box bg-black medilac-icon-box">
                <div class="promo-box-title">
                    <?php $this->get_image_icon(); ?>
                    <?php if(!empty( $heading )) : ?>
                    <h4><?php echo esc_html( $heading );?></h4>
                    <?php endif; ?>
                </div>
                <?php if(!empty( $box_text )) : ?>
                <div class="promo-box-info">
                    <p><?php echo esc_html( $box_text );?></p>
                </div>
                <?php endif; ?>
                <?php if( !empty( $text ) && !empty( $link ) ) : ?>
                <a href="<?php echo esc_url( $link );?>" <?php echo esc_attr( $target );?> <?php echo esc_attr( $nofollow );?> class="link"><?php echo esc_attr( $text );?> <i class="fas fa-arrow-right"></i></a>
                <?php endif; ?>
            </div>
        <?php }elseif('3' == $settings['icon_box_style']){?>
            <div class="service-item medilac-icon-box">
                <div class="service-icon">
                    <?php $this->get_image_icon(); ?>
                </div>
                <div class="service-info">
                    <?php if(!empty( $heading )) : ?>
                    <h2><?php echo esc_html( $heading );?></h2>
                    <?php endif; ?>
                    <?php if(!empty( $box_text )) : ?>
                    <p class="para"><?php echo esc_html( $box_text );?></p>
                    <?php endif; ?>
                    <?php if( !empty( $text ) && !empty( $link ) ) : ?>
                    <a href="<?php echo esc_url( $link );?>" <?php echo esc_attr( $target );?> <?php echo esc_attr( $nofollow );?> class="link-v1"><?php echo esc_attr( $text );?> <i class="fas fa-angle-double-right"></i></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php }elseif('4' == $settings['icon_box_style']){?>
            <div class="page-template-template-home3 promo-box promo-box-appointment medilac-icon-box">
                <div class="promo-box promo-box-appointment">
                    <div class="promo-img">
                      <?php $this->get_image_icon(); ?>
                    </div>
                    <div class="promo-text">
                        <?php if(!empty( $heading )) : ?>
                            <div class="promo-title"><?php echo esc_html( $heading );?></div>
                        <?php endif; ?>
                        <?php if(!empty( $box_text )) : ?>
                            <div class="promo-desc">
                                <?php echo esc_html( $box_text );?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php }elseif('5' == $settings['icon_box_style']){?>
            <div class="page-template-template-home4 medilac-icon-box">
                <div class="services-area">
                    <div class="single-service">
                        <div class="service-icon">
                            <?php $this->get_image_icon(); ?>
                        </div>
                        <div class="service-texts">
                            <?php if(!empty( $heading )) : ?>
                                <div class="service-title"><?php echo esc_html( $heading );?></div>
                            <?php endif; ?>
                            <?php if(!empty( $box_text )) : ?>
                                <div class="service-desc">
                                    <?php echo esc_html( $box_text );?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>  
                </div>
          </div>
        <?php }elseif ('6' == $settings['icon_box_style']) {?>
            <div class="page-template-template-home3 medilac-icon-box">
                <div class="single-department">
                    <?php $this->get_image_icon(); ?>
                    <?php if(!empty( $heading )) : ?>
                    <p><?php echo esc_html( $heading );?></p>
                    <?php endif; ?>
                </div>                  
            </div>
        <?php }
    }
    
    protected function _content_template() {}
    
}
<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Product extends Widget_Base{
    
    /**
     * Widget About Us
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_product';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Content Product', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Product';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-woocommerce';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'product', 'products'];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register Product
        $this->register_general_controls();
        // Register Product image
        $this->register_product_image();
         // Register Product Section title
        $this->register_product_section_title();
        // Register About Us Button
        $this->register_product_button();
        // Style of sub title
        $this->register_sub_title_style();
        // Product  title style
        $this->register_product_title_style();
        // About Button Style
        $this->register_product_style_controls();
    }
    
    /**
     * Register Product Settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'normal_product_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'product_styles',
            [
                'label'     => esc_html__( 'Product Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get Product image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_image(){
        $this->start_controls_section(
            'product_image_settings',
            [
                'label'     => esc_html__( 'Product Image', 'medilac' ),
            ]
        );
        $this->add_control(
            'product_image',
            [
                'label'     => __( 'Select Image', 'medilac' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Section title and sub title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_section_title(){
        $this->start_controls_section(
                'product_sub_heading_settings',
            [
                    'label'     => esc_html__( 'Product Title', 'medilac' ),
            ]
        );
       $this->add_control(
            'product_sub_title',
                [
                    'label'         => esc_html__( 'Sub Title', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'default'       => __( 'Hot Sale On', 'medilac' ),
                    'label_block'   => TRUE,
                ]
        );
        $this->add_control(
            'product_title',
                [
                    'label'         => esc_html__( 'Title', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'default'       => __( 'Health Pulse Oximeter', 'medilac' ),
                    'label_block'   => TRUE,
                ]
        );
	$this->end_controls_section();
    }

    /**
     * Register About Us Read More Button
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_button(){
	$this->start_controls_section(
            'product_button',
            [
                'label'     => __( 'Product Button', 'medilac' ),
                
            ]
        );
        $this->add_control(
            'product_btn_text',
            [
                'label'     => esc_html__( 'Text', 'medilac' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Read More', 'medilac' ),
                'pleaceholder'  => __( 'Read More', 'medilac' ),
                'dynamic'       => [
                    'active'    => true,
                ]
            ]
        );
        $this->add_control(
            'product_btn_link',
            [
                'label'     => esc_html__( 'Link', 'medilac' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'medilac' ),
                'show_external' => true,
                'default' => [
                        'url' => '',
                        'is_external' => true,
                        'nofollow' => true,
                ],
            ]
        );
	$this->end_controls_section();
    }
    
    /**
     * Register Sub Title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_sub_title_style() {
        $this->start_controls_section(
            'product_sub_title_style',
            [
                'label'      => __( 'Sub Title', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'product_sub_title_item_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home4.medilac .single-offer p.offer-subheading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'product_sub_title_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac .single-offer p.offer-subheading',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'product_sub_shadow',
                'selector'  => '{{WRAPPER}} .page-template-template-home4.medilac .single-offer p.offer-subheading',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'product_sub_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac .single-offer p.offer-subheading',
            ]
        );
        $this->add_control(
            'product_sub_title_color',
            [
                'label' => __( 'Item Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4.medilac .single-offer p.offer-subheading' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Product Title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_title_style() {
        $this->start_controls_section(
            'section_product_title_style',
            [
                'label'      => __( 'Title', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'product_title_item_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .medilac-content .content-title h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'product_titles_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'product_title_sub_shadow',
                'selector'  => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'product_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );
        $this->add_control(
            'product_title_color',
            [
                'label' => __( 'Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .single-offer p.offer-heading' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Button style here.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_style_controls() {

        $this->start_controls_section(
            'product_pricing_style',
            [
                'label'      => __( 'Button', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->start_controls_tabs( 'product_table_btn' );
        $this->start_controls_tab(
            'product_content_normal',
            [
                'label'  => esc_html__( 'Normal', 'medilac' )
            ]
        );
        $this->add_control(
            'product_btn_normal_', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'product_btn_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'product_btn_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'product_btn_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3',
            )
        );
        $this->add_responsive_control(
            'product_btn_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'product_btn_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'product_table_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'product_table_shadow',
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3',
            )
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'product_btn_content_hover',
            [
                'label' => esc_html__( 'Hover', 'medilac' ),
            ]
        );
        $this->add_control(
            'product_button_label_hover',
            array(
                'label'       => esc_html__( 'Button Label Color', 'medilac' ),
                'type'        => Controls_Manager::COLOR,
                'selectors'	 => [
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover' => 'color: {{VALUE}};'
                ],
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'hover_product_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'product_table_hover_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'hover_product_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover',
            )
        );
        $this->add_responsive_control(
            'hover_button_product_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'hover_button_product_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'product_hover_border_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'product_hover_box_shadow',
                'selector' => '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3:hover',
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control(
            'product_btn_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home4.medilac a.offer-btn.btn.v3' => 'text-align: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );

        $this->end_controls_section();
    }
    
    /**
     * Render Product  image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
     public function render_product_image(){
        $settings   = $this->get_settings_for_display();
        $product_image     = isset( $settings['product_image']['url'] ) ? $settings['product_image']['url'] : '';
        if(!empty( $product_image )){?>
            <div class="offer-img">
                <img src="<?php echo esc_url( $product_image );?>" alt="<?php esc_attr__( 'product Image', 'medilac' )?>">
            </div>
        <?php }
    }
    
    /**
     * Render Section title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
     public function render_section_title(){
        $settings   = $this->get_settings_for_display();
        $product_sub_title   = isset( $settings['product_sub_title'] ) ? $settings['product_sub_title'] : '';
        $product_title   = isset( $settings['product_title'] ) ? $settings['product_title'] : '';
        if( ! empty( $product_sub_title ) || !empty( $product_title ) ){?>
            <?php if(!empty( $product_sub_title )) : ?>
            <p class="offer-subheading"><?php echo esc_html( $product_sub_title );?></p>
            <?php endif; ?>
            <?php if(!empty( $product_title )) : ?>
            <p class="offer-heading"><?php echo esc_attr( $product_title );?></p>
            <?php endif; ?>
        <?php }
     }
     
    /**
     * Render About Us Button
     * 
     * @access protected
     * 
     * @since 1.0.0
     */  
    public function render_product_read_more(){
        $settings   = $this->get_settings_for_display();
        $product_btn_text       = isset( $settings['product_btn_text'] ) ? $settings['product_btn_text'] : '';
        $product_btn_link              = isset( $settings['product_btn_link']['url'] ) ? $settings['product_btn_link']['url'] : '';
        $pr_target            = $settings['product_btn_link']['is_external'] ? ' target="_blank"' : '';
        $pr_nofollow          = $settings['product_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
        if( ! empty( $product_btn_text ) ){ ?>
            <a href="<?php echo esc_url( $product_btn_link );?>" <?php echo esc_attr($pr_target);?> <?php echo esc_attr($pr_nofollow);?> class="offer-btn btn v3"><?php echo esc_html( $product_btn_text );?></a>
        <?php }
     }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        if( isset( $settings['product_styles'] ) && '1' == $settings['product_styles'] ){?>
            <div class="page-template-template-home4 medilac">
                <div class="single-offer">
                    <div class="offer-texts">
                      <?php $this->render_section_title();?>
                      <?php $this->render_product_read_more();?>
                    </div>
                    <?php $this->render_product_image();?>
                </div>
            </div>
        <?php }elseif('2' == $settings['product_styles']) { ?>
            <div class="page-template-template-home4 medilac product-two">
                <div class="offer-column">
                    <div class="single-offer pink">
                      <div class="offer-texts">
                        <?php $this->render_section_title();?>
                        <?php $this->render_product_read_more();?>
                      </div>
                      <?php $this->render_product_image();?>           
                    </div>
                </div>
            </div>
        <?php }
    }
    
    protected function _content_template() {}
    
}
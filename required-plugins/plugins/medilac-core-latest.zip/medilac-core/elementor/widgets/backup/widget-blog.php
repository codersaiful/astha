<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Blog extends Widget_Base{
    
    /**
     * Widget Blog section
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_blog';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Blog Section', 'medilac' );
    }
    
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Help address.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Blog';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-post';
    }
    
    /**
     * Get keyword
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string search keyword
     */
    public function get_keywords() {
        return [ 'medilac', 'blog', 'blogs', 'posts', 'post' ];
    }
    
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Get All Category here.
     *
     * @since 1.0.0
     * @access protected
     */    
    public function get_terms(){
        $terms = get_terms( 'category', 'orderby=count&hide_empty=0' );
	    $list   = array();
	    foreach($terms as $key => $value){
	        $list[$value->term_id]  = $value->name;
        }
        return $list;
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        /**
        * Select your blog sytle
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'blog_style_settings',
            [
                'label'     => esc_html__( 'Blog style', 'medilac' ),
            ]
        );
        $this->add_control(
            'blog_style',
            [
                'label'     => esc_html__( 'Blog Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
   
        /**
        * Get Blog Contents
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'filter', [
                'label' => __( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'posts_per_page', [
                'label'         => esc_html__( 'Posts Per Pages', 'medilac' ),
                'type'          => Controls_Manager::NUMBER,
                'default'       => 3,
                'min'           => -1,
                'max'           => 30,
                'step'          => 1,
            ]
        );
        $this->add_control(
            'cat',
                array(
                        'label'         => esc_html__( 'Categories', 'medilac' ),
                        'description'   => esc_html__( 'Specifies a category that you want to show posts form it.', 'medilac' ),
                        'type'          => Controls_Manager::SELECT2,
                        'multiple'      => true,
                        'options'       => $this->get_terms(),
                        'default'       => array( '' ),
                )
        );
        $this->add_control(
            'show_read_more', [
                'label'         => esc_html__( 'Show Read More', 'medilac' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'medilac' ),
                'label_off'    => esc_html__( 'No', 'medilac' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $this->add_control(
            'read_more_text', [
                'label'         => esc_html__( 'Read More Button Text', 'medilac' ),
                'type'          => Controls_Manager::TEXT,
                'default'       => 'Learn More',
                'condition' => array(
                    'show_read_more' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'show_post_excerpt', [
                'label'         => esc_html__( 'Show Post Excerpt', 'medilac' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'medilac' ),
                'label_off'    => esc_html__( 'No', 'medilac' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $this->add_control(
            'excerpt_limit', [
                'label'         => esc_html__( 'Excerpt Limit', 'medilac' ),
                'type'          => Controls_Manager::NUMBER,
                'default'       => 12,
                'condition' => array(
                    'show_post_excerpt' => 'yes',
                ),
            ]
        );
        $this->add_control(
            'show_post_meta', [
                'label'         => esc_html__( 'Show Post Meta', 'medilac' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'medilac' ),
                'label_off'    => esc_html__( 'No', 'medilac' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        $this->add_control(
            'show_post_date', [
                'label'         => esc_html__( 'Show Post Date', 'medilac' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'medilac' ),
                'label_off'    => esc_html__( 'No', 'medilac' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'     => array(
                    'show_post_meta'   => array('yes' ),
                )
            ]
        );
        $this->add_control(
            'show_post_author', [
                'label'         => esc_html__( 'Show Post Author', 'medilac' ),
                'type'          => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'medilac' ),
                'label_off'    => esc_html__( 'No', 'medilac' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'     => array(
                    'show_post_meta'   => array('yes', ),
                    'blog_style'       => array('2'),
                )
            ]
        );
        
        /**
        * Style Blog Post Order
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->add_control(
            'order', [
                'label'     => esc_html__( 'Order', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => [
                    'ASC'       => 'ASC',
                    'DESC'      => 'DESC',
                ],
                'default'       => 'ASC',
            ]
        );
        $this->add_control(
            'blog_orderby',[
                    'label'     => esc_html__( 'Order By', 'medilac' ),
                    'type'      => Controls_Manager::SELECT,
                    'options'   => [
                        ''          => esc_html__( 'Select order by', 'medilac' ),
                        'date'      => esc_html__( 'Date', 'medilac' ),
                        'name'      => esc_html__( 'Name', 'medilac' ),
                        'modified'      => esc_html__( 'Modified', 'medilac' ),
                        'author'      => esc_html__( 'Author', 'medilac' ),
                        'rand'      => esc_html__( 'Rand', 'medilac' ),
                        'comment_count'      => esc_html__( 'Comment Count', 'medilac' ),
                    ]
            ]
        );

        /**
        * Style Blog title 
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->end_controls_section();
            $this->start_controls_section(
            'blog_section',[
                'label'     => esc_html__( 'Blog Title', 'medilac' ),
                'tab'      => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'section_title_color',[
                'label'     => esc_html__( 'Color:', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .news-item-wrap .news-info h2, .news-wrap-left.medilac-left .news-info h2, .news-info h2' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'blog_title_typography',
                'label' => esc_html__( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .news-item-wrap .news-info h2, .news-wrap-left.medilac-left .news-info h2, .news-info h2',
            ]
        );
        $this->add_responsive_control(
            'title_align',
            [
                'label' => esc_html__( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify'	 => [
                        'title'	 =>esc_html__( 'Justified', 'medilac' ),
                        'icon'	 => 'fa fa-align-justify',
                    ],
                ],
                'default'       => 'none',
                'selectors'     => [
                    '{{WRAPPER}} .news-item-wrap .news-info h2, .news-wrap-left.medilac-left .news-info h2, .news-info h2' => 'text-align: {{value}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_title_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-item-wrap .news-info h2, .news-wrap-left.medilac-left .news-info h2, .news-info h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'blog_title_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-item-wrap .news-info h2, .news-wrap-left.medilac-left .news-info h2, .news-info h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
        
        /**
        * Style Blog Content 
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->end_controls_section();
            $this->start_controls_section(
            'blog_content_section',[
                'label'     => esc_html__( 'Blog Content', 'medilac' ),
                'tab'      => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'section_content_color',[
                'label'     => esc_html__( 'Color:', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .news-wrap-left.medilac-left .para, .post-des.para' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'blog_content_typography',
                'label' => esc_html__( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .news-wrap-left.medilac-left .para, .post-des.para',
            ]
        );
        $this->add_responsive_control(
            'content_align',
            [
                'label' => esc_html__( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify'	 => [
                        'title'	 =>esc_html__( 'Justified', 'medilac' ),
                        'icon'	 => 'fa fa-align-justify',
                    ],
                ],
                'default'       => 'none',
                'selectors'     => [
                    '{{WRAPPER}} .news-wrap-left.medilac-left .para, .post-des.para' => 'text-align: {{value}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-wrap-left.medilac-left .para, .post-des.para' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'blog_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-wrap-left.medilac-left .para, .post-des.para' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
        
        /**
        * Style Read more content and Icon
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->end_controls_section();
            $this->start_controls_section(
            'blog_readmore_section',[
                'label'     => esc_html__( 'Read More', 'medilac' ),
                'tab'      => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'section_readmore_color',[
                'label'     => esc_html__( 'Color:', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .news-item-wrap .news-info .read-more, .news-item-wrap .news-info .read-more i, .news-item.medilac-right .news-info .read-more, .news-item.medilac-right .news-info .read-more' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'readmore_align',
            [
                'label' => esc_html__( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify'	 => [
                        'title'	 =>esc_html__( 'Justified', 'medilac' ),
                        'icon'	 => 'fa fa-align-justify',
                    ],
                ],
                'default'       => 'none',
                'selectors'     => [
                    '{{WRAPPER}} .news-item-wrap .news-info .read-more, .news-item-wrap .news-info .read-more i, .news-item.medilac-right .news-info .read-more, .news-item.medilac-right .news-info .read-more' => 'text-align: {{value}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'blog_readmore_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-item-wrap .news-info .read-more, .news-item-wrap .news-info .read-more i, .news-item.medilac-right .news-info .read-more, .news-item.medilac-right .news-info .read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'blog_readmore_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .news-item-wrap .news-info .read-more, .news-item-wrap .news-info .read-more i, .news-item.medilac-right .news-info .read-more, .news-item.medilac-right .news-info .read-more i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->end_controls_section();
        
        
    }
    
    /**
    * Render oEmbed widget output on the frontend.
    *
    * Written in PHP and used to generate the final HTML.
    *
    * @since 1.0.0
    * @access protected
    */
    protected function render() {
        $settings                       = $this->get_settings();
        $posts_per_page                 = isset($settings['posts_per_page']) ? $settings['posts_per_page'] : '3';
        $order                          = isset($settings['order']) ? $settings['order'] : '';
        $blog_orderby                   = isset($settings['blog_orderby']) ? $settings['blog_orderby'] : '';
        $show_read_more                 = isset($settings['show_read_more']) ? $settings['show_read_more'] : '';
        $read_more_text                 = isset($settings['read_more_text']) ? $settings['read_more_text'] : '';
        $show_post_excerpt              = isset($settings['show_post_excerpt']) ? $settings['show_post_excerpt'] : '';
        $excerpt_limit                  = isset($settings['excerpt_limit']) ? $settings['excerpt_limit'] : '12';
        $show_post_meta                 = isset($settings['show_post_meta']) ? $settings['show_post_meta'] : 'yes';
        $show_post_author               = isset($settings['show_post_author']) ? $settings['show_post_author'] : '';
        $show_post_date                 = isset($settings['show_post_date']) ? $settings['show_post_date'] : '';
        $cat                            = isset($settings['cat']) ? $settings['cat'] : '';
        $categories                     = get_terms( 'category', 'orderby=count&hide_empty=0' );
        $categories_list                = array( ' ' => __( 'All Categories', 'medilac' ) )  ;
        foreach ( $categories as $key => $value ) {
            $categories_list[$value->term_id] = $value->name;
        }
        $posts = new \WP_Query(array(
            'post_type'     => 'post',
            'posts_per_page'=> $posts_per_page,
            'order'         => $order,
            'orderby'       => $blog_orderby,
            'cat'           => $cat,
            'post_status'   => 'publish',
            'ignore_sticky_posts'   => true,
        ));
        $count = 0;
        ?>
        <?php if( isset( $settings['blog_style'] ) && '1' == $settings['blog_style'] ){?>
            <!--  News Section start-->
            <section class="news-area section-padding">
                <div class="medilac-home-container">
                    <div class="row">
                        <div class="news-item-wrap">
                            <?php while($posts->have_posts()) : $posts->the_post();?>
                            <div class="news-item">
                                <div class="news-img">
                                    <?php the_post_thumbnail( array( 370, 280 ) ); // Other resolutions (height, width);?>
                                     <?php if('yes' === $show_post_meta && ('yes' === $show_post_date)) : ?>
                                    <a href="#" class="news-date">
                                        <?php the_time( get_option( 'date_format' ) ); ?>
                                    </a>
                                    <?php endif;?>
                                </div>
                                <div class="news-info">
                                    <h2><?php the_title();?></h2>
                                    <?php if('yes' == $show_post_excerpt && !empty($excerpt_limit)) : ?>
                                    <div class="post-des para">
                                        <?php echo wp_trim_words(get_the_content(), $excerpt_limit, '');?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if('yes' == $show_read_more && !empty($read_more_text)) : ?>
                                    <a class="read-more" href="<?php the_permalink();?>"><?php echo esc_html($read_more_text);?><i class="fas fa-angle-double-right"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endwhile;?>
                        </div>
                    </div>
                </div>
            </section>
            <!--  News Section end-->            
        <?php }else{?>
             <!-- News section start -->
            <section class="news-area v2 bg-zircon">
              <div class="medilac-home-container">
                <div class="row">
                    <?php while($posts->have_posts()) : $posts->the_post();?>
                       <?php if ($count == 0) {?>
                        <div class="news-wrap-left medilac-left">
                          <div class="news-item">
                            <div class="news-img">
                                <?php the_post_thumbnail( array( 570, 360 ) ); // Other resolutions (height, width);?>
                                <?php if('yes' === $show_post_meta && ('yes' === $show_post_date)) : ?>
                                <a href="#" class="news-date">
                                  <?php the_time( get_option( 'date_format' ) ); ?>
                                </a>
                                <?php endif; ?>
                            </div>
                            <div class="news-info">
                                <h2><?php the_title();?></h2>
                                <?php if('yes' == $show_post_excerpt && !empty($excerpt_limit)) : ?>
                                 <div class="para">
                                     <?php echo wp_trim_words(get_the_content(), $excerpt_limit, '');?>
                                 </div>
                                 <?php endif; ?>
                                <?php if('yes' == $show_read_more && !empty($read_more_text)) : ?>
                                <a href="<?php the_permalink();?>" class="read-more"><?php echo esc_html($read_more_text);?> <i class="fas fa-angle-double-right"></i></a>
                                <?php endif;?>
                            </div>
                          </div>
                        </div>
                       <?php }if ($count >= 1) { ?>
                        <div class="news-item medilac-right">
                            <div class="news-img">
                              <?php the_post_thumbnail( array( 370, 280 ) ); // Other resolutions (height, width);?>
                            </div>
                            <div class="news-info">
                              <div class="news-meta">
                                <?php if('yes' === $show_post_meta && 'yes' === $show_post_author) : ?>
                                <span class="news-author"><i class="far fa-user"></i><?php the_author_posts_link(); ?></span>
                                <?php endif; ?>
                                <?php if('yes' === $show_post_meta && ('yes' === $show_post_date)) : ?>
                                <span class="published-date"><i class="far fa-calendar-alt"></i><?php the_time( get_option( 'date_format' ) ); ?></span>
                                <?php endif; ?>
                              </div>
                              <h2><?php the_title();?></h2>
                              <?php if('yes' == $show_read_more && !empty($read_more_text)) : ?>
                              <a href="<?php the_permalink();?>" class="read-more"><?php echo esc_html($read_more_text);?> <i class="fas fa-angle-double-right"></i></a>
                               <?php endif; ?>
                            </div>
                        </div>
                    <?php } 
                        $count++; endwhile;?> 
                </div>
              </div>
            </section>
            <!-- News section end -->
        <?php }
        }
        
    protected function _content_template() {}
}
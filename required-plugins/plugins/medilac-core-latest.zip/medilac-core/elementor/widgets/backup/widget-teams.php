<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Teams extends Widget_Base{
    
    /**
     * Widget Team Members
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_teams';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Team Members', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Teams';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-lock-user';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'team', 'teams', 'member', 'members' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Register Item
        $this->register_content_controls();
        // Team Menber Name Style.
        $this->register_team_member_name();
        // Team Member Designation.
        $this->register_team_member_designation();
    }
    
    /**
     * Register Team Members General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'team_members_top',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'team_style',
            [
                'label'     => esc_html__( 'Members Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Team Members Content Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_content_controls(){
	$this->start_controls_section(
            'section_features',
            [
                    'label'     => __( 'Team Members', 'medilac' ),
            ]
        );
        $repeater   = new Repeater();
        $repeater   ->add_control(
            'team_image',
            [
                'label'     => __( 'Team Image', 'medilac' ),
                'type'     => Controls_Manager::MEDIA,
                'descripton'    => __( 'Our Recommended size 300x300px', 'medilac' ),
            ]
        );
        $repeater->add_control(
             'team_name',
             [
                 'label'    => __( 'Team Name', 'medilac' ),
                 'type' => Controls_Manager::TEXT,   
                 'label_block'  => TRUE,
             ]
        );
        $repeater->add_control(
             'team_designation',
             [
                 'label'    => __( 'Team Designation', 'medilac' ),
                 'type' => Controls_Manager::TEXT,   
                 'label_block'  => TRUE,
             ]
        );
        $repeater->add_control(
            'show_readmore_btn',
                [
                    'label'     => __( 'Show Readmore Button', 'medilac' ),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__( 'Yes', 'medilac' ),
                    'label_off' => esc_html__( 'No', 'medilac' ),
                    'return_value'  => 'yes',
                    'default'       => 'no',
                ]
        );
        $repeater->add_control(
            'read_more_url',
            [
                'label'     => __( 'Type URL:', 'medilac' ),
                'label_bloack'  => TRUE,
                'type'      => Controls_Manager::URL,
                'condition' => [
                    'show_readmore_btn'    => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'item_advanced_settings',
                [
                    'label'     => __( 'Show Socials', 'medilac' ),
                    'type'      => Controls_Manager::SWITCHER,
                    'label_on'  => esc_html__( 'Yes', 'medilac' ),
                    'label_off' => esc_html__( 'No', 'medilac' ),
                    'return_value'  => 'yes',
                    'default'       => 'no'
                ]
        );
        $repeater->add_control(
            'icon_one',
                [
                    'label'     => __( 'Select Icon One', 'medilac' ),
                    'type'      => Controls_Manager::ICONS,
                    'condition' => [
                        'item_advanced_settings' => 'yes',
                    ],
                ]
        );
        $repeater->add_control(
            'icon_one_url',
            [
                'label'     => __( 'Icon URL One:', 'medilac' ),
                'label_bloack'  => TRUE,
                'type'      => Controls_Manager::URL,
                'condition' => [
                    'item_advanced_settings'    => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'icon_two',
                [
                    'label'     => __( 'Select Icon Two', 'medilac' ),
                    'type'      => Controls_Manager::ICONS,
                    'condition' => [
                        'item_advanced_settings' => 'yes',
                    ],
                ]
        );
        $repeater->add_control(
            'icon_two_url',
            [
                'label'     => __( 'Icon URL Two:', 'medilac' ),
                'type'      => Controls_Manager::URL,
                'condition' => [
                    'item_advanced_settings'    => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'icon_three',
                [
                    'label'     => __( 'Select Icon three', 'medilac' ),
                    'type'      => Controls_Manager::ICONS,
                    'condition' => [
                        'item_advanced_settings' => 'yes',
                    ],
                ]
        );
        $repeater->add_control(
            'icon_three_url',
            [
                'label'     => __( 'Icon URL Three:', 'medilac' ),
                'type'      => Controls_Manager::URL,
                'condition' => [
                    'item_advanced_settings'    => 'yes',
                ],
            ]
        );
        
        $this->add_control(
            'team_list',
            [
                'type'      => Controls_Manager::REPEATER,
                'fields'    => array_values( $repeater->get_controls() ),
                'default'   => [
                    [
                        'team_name'         => __( 'Dr. Michle Retoshiba', 'medilac' ),
                        'team_designation'  => 'MBBS of Cardiology',
                    ],
                    [
                        'team_name'         => __( 'Dr. Richita Carnivalo', 'medilac' ),
                        'team_designation'  => 'MBBS of Medicine',
                    ],
                ],
                'title_field'   => '{{{ team_name }}}',
            ]
        );
	$this->end_controls_section();
    }
    
    /**
     * Team Member Name.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_team_member_name(){
	$this->start_controls_section(
	            'team_member_name_label',
                [
                    'label'     => esc_html__( 'Team Member Name:', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'team_member_name_content', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'teams_member_name_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'team_member_name_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'team_member_name_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2',
            )
        );
        $this->add_responsive_control(
            'team_members_name_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'team_member_name_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'team_member_name_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'team_member_shadow',
                'selector' => '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2',
            )
        );
        $this->add_control(
            'team_member_name_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home3 .doc-info h2, section.team-area.section-padding .member-info h2' => 'text-align: {{value}};',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
	    $this->end_controls_section();
    }
    
    /**
     * Team Member Designation.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_team_member_designation(){
	$this->start_controls_section(
	            'team_member_designation_settings',
                [
                    'label'     => esc_html__( 'Team Designation', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'team_member_designation_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'team_designaiton_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'team_member_designation_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'team_member_designation_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .single-team-item .member-name span.para',
            )
        );
        $this->add_responsive_control(
            'team_member_designation_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'team_member_designation_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'team_designation_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'team_member_designation_shadow',
                'selector' => '{{WRAPPER}} .single-team-item .member-name span.para, .page-template-template-home3 .doc-info p.para',
            )
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Team Members Pricing Style Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
 
    public function get_slider_teams(){
        $settings       = $this->get_settings_for_display();
        $team_lists     = isset( $settings['team_list'] ) ? $settings['team_list'] : '';
        foreach((array) $team_lists as $team_list ){ ?>
        <div class="item">
            <div class="single-team-item">
                <div class="member-avatar">
                    <?php if(!empty( $team_list['team_image']['url']) ) : ?>
                    <div class="medilac-round">
                        <img src="<?php echo esc_url( $team_list['team_image']['url'] );?>" alt="<?php esc_attr__( 'Team Image', 'medilac' );?>">
                    </div>
                    <?php endif; ?>
                    
                    <?php if('yes' == $team_list['item_advanced_settings']){
                    $link1               = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                    $target1             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                    $nofollow1           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';

                    $link2              = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                    $target2             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                    $nofollow2           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';

                    $link3              = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                    $target3             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                    $nofollow3           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';
                    ?>
                    <div class="member-social-link">
                        <ul>
                            <?php if(!empty( $team_list['icon_one']['value'] )) : ?>
                            <li><a href="<?php echo esc_url( $link1 );?>" <?php echo esc_attr( "'. $target1 .' '.$nofollow1.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_one']['value'] ); ?>"></i></a></li>
                            <?php endif; ?>
                            <?php if(!empty( $team_list['icon_two']['value'] )) : ?>
                            <li><a href="<?php echo esc_url( $link2 ); ?>" <?php echo esc_attr( "'. $target2 .' '.$nofollow2.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_two']['value'] );?>"></i></a></li>
                            <?php endif; ?>
                            <?php if(!empty( $team_list['icon_three']['value'] )) : ?>
                            <li><a href="<?php echo esc_url( $link3 );?>" <?php echo esc_attr( "'. $target3 .' '.$nofollow3.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_three']['value'] );?>"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php }?>
                </div>
                <div class="member-info">
                    <div class="member-name">
                        <?php if(!empty( $team_list['team_name']) ) : ?>
                        <h2><?php echo esc_html( $team_list['team_name'] );?></h2>
                        <?php endif; ?>
                        <?php if(!empty( $team_list['team_designation']) ) : ?>
                        <span class="para"><?php echo esc_html( $team_list['team_designation'] );?></span>
                        <?php endif; ?>
                    </div>
                    <?php 
                    $settings       = $this->get_settings_for_display();
                    $team_lists     = isset( $settings['team_list'] ) ? $settings['team_list'] : '';
                        if( 'yes' == $team_list['show_readmore_btn'] ) { 
                            $link_url           = isset( $team_list['read_more_url']['url'] ) ? $team_list['read_more_url']['url'] : '';
                            $tar                = $team_list['read_more_url']['is_external'] ? ' target="_blank"' : '';
                            $nofoll             = $team_list['read_more_url']['nofollow'] ? ' rel="nofollow"' : '';
                            ?>
                            <div class="member-btn">
                                <a href="<?php echo esc_url( $link_url );?>" <?php echo esc_attr( "'. $tar .' '.$nofoll.'" );?>><i class="fas fa-angle-double-right"></i></a>
                            </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php }
    }

    
    /**
     * Get Team Members Contents
     * 
     * @access Public
     * 
     * @since 1.0.0
     */
    public function get_team_members(){
        $settings       = $this->get_settings_for_display();
        $team_lists     = isset( $settings['team_list'] ) ? $settings['team_list'] : '';
        foreach((array) $team_lists as $team_list ){ ?>
        <div class="doc-item">
            <?php if(!empty( $team_list['team_image']['url']) ) : ?>
            <div class="doc-img">
                <img src="<?php echo esc_url( $team_list['team_image']['url'] );?>" alt="<?php esc_attr__( 'Team Image', 'medilac' );?>">
            </div>
            <?php endif; ?>
            
            <?php if('yes' == $team_list['item_advanced_settings']){
                $link1              = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                $target1             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                $nofollow1           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';
                
                $link2              = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                $target2             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                $nofollow2           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';
                
                $link3              = isset( $team_list['icon_one_url']['url'] ) ? $team_list['icon_one_url']['url'] : '';
                $target3             = $team_list['icon_one_url']['is_external'] ? ' target="_blank"' : '';
                $nofollow3           = $team_list['icon_one_url']['nofollow'] ? ' rel="nofollow"' : '';
                ?>
            <div class="doc-social-wrap">
              <div class="social-links">
                <a href="#"><i class="fas fa-plus"></i></a>
                <?php if(!empty( $team_list['icon_one']['value'] )) : ?>
                <a href="<?php echo esc_url( $link1 );?>" <?php echo esc_attr( "'. $target1 .' '.$nofollow1.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_one']['value'] ); ?>"></i></a>
                <?php endif; ?>
                <?php if(!empty( $team_list['icon_two']['value'] )) : ?>
                <a href="<?php echo esc_url( $link2 ); ?>" <?php echo esc_attr( "'. $target2 .' '.$nofollow2.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_two']['value'] );?>"></i></a>
                <?php endif; ?>
                <?php if(!empty( $team_list['icon_three']['value'] )) : ?>
                <a href="<?php echo esc_url( $link3 );?>" <?php echo esc_attr( "'. $target3 .' '.$nofollow3.'" );?>><i class="fas <?php echo esc_attr( $team_list['icon_three']['value'] );?>"></i></a>
                <?php endif; ?>
              </div>
            </div>                
            <?php }?>

            <div class="doc-info">
                <?php if(!empty( $team_list['team_name']) ) : ?>
                <h2><?php echo esc_html( $team_list['team_name'] );?></h2>
                <?php endif; ?>
                <?php if(!empty( $team_list['team_designation']) ) : ?>
                <p class="para"><?php echo esc_html( $team_list['team_designation'] );?></p>
                <?php endif; ?>
            </div>
            <?php 
                $settings       = $this->get_settings_for_display();
                $team_lists     = isset( $settings['team_list'] ) ? $settings['team_list'] : '';
                if( 'yes' == $team_list['show_readmore_btn'] ) { 
                    $link_url           = isset( $team_list['read_more_url']['url'] ) ? $team_list['read_more_url']['url'] : '';
                    $tar                = $team_list['read_more_url']['is_external'] ? ' target="_blank"' : '';
                    $nofoll             = $team_list['read_more_url']['nofollow'] ? ' rel="nofollow"' : '';
                    ?>
                    <div class="member-btn">
                        <a href="<?php echo esc_url( $link_url );?>" <?php echo esc_attr( "'. $tar .' '.$nofoll.'" );?>><i class="fas fa-angle-double-right"></i></a>
                    </div>
                <?php }
            ?>
        </div>
        <?php }
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        if( isset( $settings['team_style'] ) && '1' == $settings['team_style'] ){?>
        <!-- Doctor Section start-->
        <section class="page-template-template-home3 doc-area medilac-team">
          <div class="medilac-home-container">
            <div class="row">
              <div class="doc-item-wrap">
                  <?php $this->get_team_members();?>       
              </div>
            </div>
          </div>
        </section>
        <!--  Doctor Section end-->   
        <?php }else {?>
        <!-- Team Section start-->
        <section class="team-area medilac-teams">
            <img src="<?php echo get_template_directory_uri().'/assets/images/team_bg_1.png';?>" alt="Image" class="team-bg-one">
            <img src="<?php echo get_template_directory_uri().'/assets/images/team_bg_2.png';?>" alt="Image" class="team-bg-two">
            <div class="medilac-home-container">
                <div class="row">
                    <div class="team-slider v1 owl-carousel">
                        <?php $this->get_slider_teams(); ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- Team Section end-->
        <?php }
        
    }
    
    protected function _content_template() {}
    
}
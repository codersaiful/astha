<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Progress_Bar extends Widget_Base{
    
    /**
     * Widget About Us
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_progress_bar';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Progress Bar', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Progress_Bar';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-skill-bar';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'progess', 'progess-bar'];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Style of progess bar 
        $this->register_progress_bar_title_style();
        // Style of Progess Bar Fill Style
        $this->register_progress_fill_style();
        // Style of Progess Fill style
        $this->register_progres_filled_style();
        
        
    }
    
    /**
     * Register About Us Settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'progess_bar_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
       $this->add_control(
            'progess_bar_title',
                [
                    'label'     => esc_html__( 'Title', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'default'   => __( 'Health care', 'medilac' ),
                ]
        );
        $this->add_control(
            'progess_percent',
            [
                    'label' => __( 'Percentage', 'medilac' ),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                            'size' => 50,
                            'unit' => '%',
                    ],
                    'dynamic' => [
                            'active' => true,
                    ],
            ]
        );
        $this->end_controls_section();
    }

    
    /**
     * Register Progress Bar title Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_progress_bar_title_style() {
        $this->start_controls_section(
            'progess_bar_title_style',
            [
                'label'      => __( 'Progess Title', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'progess_bar_title_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home3 .bar .para' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'progess_bar_title_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home3 .bar .para',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'progess_bar_title_shadow',
                'selector'  => '{{WRAPPER}} .page-template-template-home3 .bar .para',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'progess_bar_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home3 .bar .para',
            ]
        );
        $this->add_control(
            'progess_bar_title_color',
            [
                'label' => __( 'Item Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home3 .bar .para' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
     
        
    /**
     * Register Progress Bar FIll style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_progress_fill_style() {
        $this->start_controls_section(
            'progessed_bar_filled_title_style',
            [
                'label'      => __( 'Progess Filled', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->add_responsive_control(
            'progess_bar_filled_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper span.fill' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'progess_bar_filled_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper span.fill',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'progess_bar_filled_shadow',
                'selector'  => '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper span.fill',
            ]
        );
        $this->end_controls_section();
    }
     
        /**
     * Register Progress Bar FIll style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_progres_filled_style() {
        $this->start_controls_section(
            'progess_section_bar_title_style',
            [
                'label'      => __( 'Progess', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'progess_bar_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper .barfiller',
            ]
        );
        $this->add_responsive_control(
            'progess_bar_fill_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper .barfiller' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'progess_bar_fill_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper .barfiller',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'progess_bar_fill_shadow',
                'selector'  => '{{WRAPPER}} .page-template-template-home3 .bars .barfiller-wrapper .barfiller',
            ]
        );
        $this->end_controls_section();
    }
    
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display(); 
        $progess_bar_title = isset( $settings['progess_bar_title'] ) ? $settings['progess_bar_title'] : '';
        $progess_percent   = isset( $settings['progess_percent']['size'] ) ? $settings['progess_percent']['size'] : '';
        ?>
        <div class="page-template-template-home3">
            <div class="bars">
                <?php if(!empty( $progess_bar_title )) : ?>
                <div class="para"><?php echo esc_html( $progess_bar_title );?></div>
                <?php endif; ?>
                <div class="barfiller-wrapper">
                  <div id="bar1" class="barfiller">
                      <?php if(!empty( $progess_percent )) : ?>
                    <!-- <span class="tip"></span> -->
                      <span class="fill" data-percentage="<?php echo esc_attr( $progess_percent );?>"></span>
                      <?php endif; ?>
                  </div>
                  <p><?php echo esc_attr( $progess_percent );?>%</p>
                </div>
            </div>
        </div>
     <?php 
    }
    
    protected function _content_template() {}
    
}
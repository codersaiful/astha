<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Sponsor extends Widget_Base{
    
    /**
     * Widget Sponsor
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Sponsor
     */
    public function get_name() {
        return 'medilac_widget_sponsor';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'sponsor' );
    }
    
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Sponsor';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-logo';
    }
    
    public function get_keywords() {
        return [ 'sponsor', 'sponsors', 'medilac' ];
    }

    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    protected function _register_controls() {
        /**
        * Select your sponsor style here.
        * 
        * @access protected
        * 
        * @since 1.0.0
        */    
        $this->start_controls_section(
                'sponsor_generel_section', 
                [
                    'label'     => esc_html( 'General Setting', 'medilac' )
                ]
        );
        $this->add_control(
            'style',
            [
                'label'         => esc_html__( 'Choose Style', 'medilac' ),
                'type'          => Controls_Manager::SELECT,
                'default'       => 'style1',
                'options'       => [
                    'slider' => esc_html__( 'Slider Style', 'medilac' ),
                    'normal' => esc_html__( 'Normal Sytle', 'medilac' ),
                ],
                'default'   => 'normal',
            ]
        );
        $this->end_controls_section();

        /**
        * Sponsor Items here
        * 
        * @access protected
        * 
        * @since 1.0.0
        */  
        $this->start_controls_section(
                'sponsor_items_section', [
                    'label'     => __( 'Sponsor Items', 'medilac' ),
            ]
        );
        $this->add_control(
                'sponsors',
                [
                    'label'     => esc_html__( 'Sponsors', 'medilac' ),
                    'type'      => Controls_Manager::REPEATER,
                    'default'   => [
                        [
                            'image'             => array(
                                    'url'       => Utils::get_placeholder_image_src(),
                            ),
                            'url'               => array(
                                    'url'       => '#',
                            )
                        ],
                        [
                            'image'             => array(
                                'url'       => Utils::get_placeholder_image_src(),
                            ),
                            'url'               => array(
                                'url'       => '#',
                            )
                        ],
                        [
                            'image'             => array(
                                'url'       => Utils::get_placeholder_image_src(),
                            ),
                            'url'               => array(
                                'url'       => '#',
                            )
                        ],
                        [
                            'image'             => array(
                                'url'       => Utils::get_placeholder_image_src(),
                            ),
                            'url'               => array(
                                'url'       => '#',
                            )
                        ],
                    ],
                    'fields'        => [
                        [
                            'name' => 'image',
                            'label' => esc_html_x( 'Select Image', 'Admin Panel', 'medilac' ),
                            'type' => Controls_Manager::MEDIA,
                            'return' => true,
                            'default' => [
                                'url' => Utils::get_placeholder_image_src(),
                            ],
                        ],
                        [
                            'name'          => 'url',
                            'label'         => esc_html__( 'Image URL', 'medilac' ),
                            'type'          => Controls_Manager::URL,
                            'show_label'    => false,
                        ],
                    ],
                    'title_field' => '{{{ name }}}',
                ]
        );
        $this->end_controls_section();
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
    $settings           = $this->get_settings_for_display();
    $sponsors = isset($settings['sponsors']) ? $settings['sponsors'] : '';
    if( isset( $settings['style'] ) && 'slider' == $settings['style'] ){?>
    <!-- Partner Section start -->
     <section class="partner-area">
         <div class="medilac-home-container">
             <div class="row">
                 <div class="partner-slider owl-carousel">
                     <?php 
                     foreach((array) $sponsors as $sponsor){
                            $settings           = $this->get_settings_for_display();
                            $_link              = isset( $sponsor['url']['url'] ) ? $sponsor['url']['url'] : '';
                            $target             = $sponsor['url']['is_external'] ? ' target="_blank"' : '';
                            $nofollow           = $sponsor['url']['nofollow'] ? ' rel="nofollow"' : '';          
                         ?>
                         <div class="item">
                            <div class="partner-img">
                                <a href="<?php echo esc_url( $_link ); ?>" <?php echo esc_attr( " $target ' ' $nofollow " );?>><?php echo wp_get_attachment_image($sponsor["image"]["id"], false, array("class" => "client-logo")); ?></a>
                           </div>
                        </div>
                     <?php }?>
                 </div>
             </div>
         </div>
     </section>
    <!-- Partner Section end -->        
    <?php }else{?>
      <!-- Clients Logo Area Start -->
    <section class="page-template-template-home4 section-padding">
      <div class="medilac-home-container client-logo-area">
        <div class="row">
             <?php 
                foreach((array) $sponsors as $sponsor){
                $settings           = $this->get_settings_for_display();
                $_link              = isset( $sponsor['url']['url'] ) ? $sponsor['url']['url'] : '';
                $target             = $sponsor['url']['is_external'] ? ' target="_blank"' : '';
                $nofollow           = $sponsor['url']['nofollow'] ? ' rel="nofollow"' : '';          
                ?>
                  <a href="<?php echo esc_url( $_link ); ?>" <?php echo esc_attr( " $target ' ' $nofollow " );?>><?php echo wp_get_attachment_image($sponsor["image"]["id"], array("class" => "client-logo")); ?></a>
               <?php }?>
        </div>
      </div>
    </section>
    <!-- Clients Logo Area End -->
    <?php }
    }
    
    protected function _content_template() { }
    
}
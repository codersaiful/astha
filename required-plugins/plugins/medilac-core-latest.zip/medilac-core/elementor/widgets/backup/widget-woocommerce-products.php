<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Get Product Category Lists
function medilac_product_category_list( $cat ){
    $query_args = array(
        'orderby'       => 'ID',
        'order'         => 'DESC',
        'hide_empty'    => 1,
        'taxonomy'      => $cat
    );

    $categories = get_categories( $query_args );
    $options = array();
    if(is_array($categories) && count($categories) > 0){
        foreach ($categories as $cat){
            $options[$cat->term_id] = $cat->name;
        }
        return $options;
    }
}


class Medilac_Widget_Woocommerce_Products extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_woocommerce_products';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Woccommerce Products', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Woocommerce_Products';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-posts-grid';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'product', 'products', 'woocommerce' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
        
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register Product style
        $this->register_general_controls();
        // Register product Contents
        $this->register_product_content();
        // Heading Style
        $this->register_heading_style_controls();
        // Product Price style
        $this->register_product_price();
    }
    
    
    /**
     * Register Product Contents
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'product_page_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'products_style',
            [
                'label'     => esc_html__( 'Product Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '2',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get Product Settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_content(){
        $this->start_controls_section(
            'woocommer_product_settings',
            [
                'label'     => esc_html__( 'Product Settings', 'medilac' ),
            ]
        );
        $this->add_control(
            'woo_cats_link',
            [
                'label' => esc_html__( 'Select category', 'medilac' ),
                'type' => Controls_Manager::SELECT2,
                'options' => medilac_product_category_list('product_cat'),
                'default' => '0',
                'multiple' => 'true'
            ]
        );
        $this->add_control(
            'product_per_page', [
                'label'         => esc_html__( 'Posts Per Pages', 'medilac' ),
                'type'          => Controls_Manager::NUMBER,
                'default'       => 3,
                'min'           => -1,
                'max'           => 30,
                'step'          => 1,
            ]
        );
        $this->add_control(
            'product_col',
            [
                'label'     => esc_html__( 'Product Column', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '2'         => esc_html__( 'Col 02', 'medilac' ),
                    '3'         => esc_html__( 'Col 03', 'medilac' ),
                    '4'         => esc_html__( 'Col 04', 'medilac' ),
                    '5'         => esc_html__( 'Col 05', 'medilac' ),
                    '6'         => esc_html__( 'Col 06', 'medilac' ),
                ],
                'default'       => '4',
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Register Price Table Heading Style Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_style_controls(){
	    $this->start_controls_section(
	            'product_title',
                [
                    'label'    => __( 'Product Title', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'product_style',
            [
                'label'     => __( 'Title', 'medilac' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'product_title_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'product_title_typography',
                'selector' => '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'product_title_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'product_title_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'product_title_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title',
            ]
        );
        $this->add_control(
            'prodct_title_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-title' => 'text-align: {{VALUE}}',
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
   
    /**
     * Package Product Price Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_product_price(){
	$this->start_controls_section(
	            'product_price',
                [
                    'label'     => esc_html__( 'Product Price', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'product_price_color', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'product_price_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'product_price_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'product_price_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price',
            )
        );
        $this->add_responsive_control(
            'product_price_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'product_price_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'product_price_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'product_price_shadow',
                'selector' => '{{WRAPPER}} section.page-template-template-home4.medilac-content .shop-item .category-price',
            )
        );
        $this->end_controls_section();
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        $woo_cats_link        = isset( $settings['woo_cats_link'] ) ? $settings['woo_cats_link'] : '';
        $limit                = isset($settings['product_per_page']) ? $settings['product_per_page'] : 4;
        $product_col          = isset($settings['product_col']) ? $settings['product_col'] : 4;
        $woo_cats_link = is_array( $woo_cats_link ) ? implode( ',', $woo_cats_link ) : false;
        
        $slider = false;
        if( isset( $settings['products_style'] ) && '1' == $settings['products_style'] ){
            $slider = true;
            $product_col = 1;
        }
        
        $shortcode = '[products limit="' . $limit . '" columns="' . $product_col . '" orderby="popularity" category="' . $woo_cats_link . '" ]';
            
        if( $slider ){?>
        <!-- Category Area Start -->
        <section class="page-template-template-home4 v1 section-padding medilac-content">
          <div class="medilac-home-container category-area">
            <div class="row">
              <div class="category-item-wrap owl-carousel">
                <?php echo do_shortcode( $shortcode ); ?>
              </div>
            </div>
          </div>
        </section>
        <!-- Category Area End -->   
        <?php }else {?>
        <!-- Shop Area Style -->
        <section class="page-template-template-home4 section-padding medilac-content">
            <?php echo do_shortcode( $shortcode ); ?>
        </section>
        <!-- Shop Area Style -->
        <?php }
    }
    
    protected function _content_template() {}
    
}

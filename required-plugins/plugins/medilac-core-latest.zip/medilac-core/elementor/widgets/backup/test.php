<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
//Group_Control_Image_Size
use Elementor\Scheme_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Test extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_test';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Medilac Test', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Button';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'medilac eicon-button';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'test', 'tst', 't', 'example' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'basic' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {

        //For General Section
        $this->content_general_controls();

       
        //For Design Section Style Tab
        //$this->style_design_controls();
        
        //For Typography Section Style Tab
        //$this->style_typography_controls();

       
    }
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings           = $this->get_settings_for_display();

        $this->add_render_attribute( 'wrapper', 'class', 'medilac-button-wrapper' );
        $this->add_render_attribute( 'button', 'class', 'medilac-button' );
       
        var_dump($settings['test_gallery']);
        ?>
        <div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
            <h2>Test Element</h2>
        </div>
        <?php

    }
    
    protected function _content_template() {
        /*
        ?>
        <#
        view.addInlineEditingAttributes( 'avd_heading', 'none' );
        view.addInlineEditingAttributes( 'avd_sub_heading', 'none' );
        #>
        
        <div class="advance-heading-wrapper">
            <span {{{ view.getRenderAttributeString( 'avd_sub_heading' ) }}}>{{{ settings.avd_sub_heading }}}</span>
            <h4 class="heading-tag" {{{ view.getRenderAttributeString( 'avd_heading' ) }}}>{{{ settings.avd_heading }}}</h4>
        </div>
        <?php
        */
    }
    
    
    
    /**
     * General Section for Content Controls
     * 
     * @since 1.0.0.9
     */
    protected function content_general_controls() {
        $this->start_controls_section(
                'section_button',
                [
                        'label' => __( 'Button', 'medilac' ),
                ]
        );

        $this->add_control(
                'test_gallery',
                [
                        'label' => __( 'Add Images', 'elementor' ),
                        'type' => Controls_Manager::GALLERY,
                        'default' => [],
                        'show_label' => false,
                        'dynamic' => [
                                'active' => true,
                        ],
                ]
        );

        $this->add_group_control(
                Group_Control_Image_Size::get_type(),
                [
                        'name' => 'thumbnail', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                        'separator' => 'none',
                ]
        );
        
        $this->end_controls_section();
    }
    
    
//    
//    /**
//     * Alignment Section for Style Tab
//     * 
//     * @since 1.0.0.9
//     */
//    protected function style_design_controls() {
//        $this->start_controls_section(
//            'design',
//            [
//                'label'     => esc_html__( 'Design', 'medilac' ),
//                'tab'       => Controls_Manager::TAB_STYLE,
//            ]
//        );
//        
//        
//        
//        
//        
//        
//        $this->end_controls_section();
//    }
//    
//    /**
//     * Typography Section for Style Tab
//     * 
//     * @since 1.0.0.9
//     */
//    protected function style_typography_controls() {
//        $this->start_controls_section(
//            'mc_rc_typography',
//            [
//                'label'     => esc_html__( 'Typography', 'medilac' ),
//                'tab'       => Controls_Manager::TAB_STYLE,
//            ]
//        );
//        
//        
//        $this->end_controls_section();
//    }
//    
    
}
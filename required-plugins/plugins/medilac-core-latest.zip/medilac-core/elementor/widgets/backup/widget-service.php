<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Controls_Manager;


class Medilac_Widget_Service extends \Elementor\Widget_Base{
    
    /**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'medilac_widget_service';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Service', 'medilac' );
	}
        
        public function get_custom_help_url() {
		return 'https://wooproducttable.com/';
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-elementor-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'medilac' ];
	}
        
        public function get_keywords() {
		return [ 'service', 'offer' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
        protected function _register_controls() {
            
            $this->start_controls_section(
                    '_section_info',
                    [
                            'label' => __( 'Information', 'medilac' ),
                            'tab' => Controls_Manager::TAB_CONTENT,
                    ]
            );
            
            $this->add_control(
                    'service_title',
                    [
                            'label' => __( 'Service Title', 'medilac' ),
                            'label_block' => true,
                            'type' => Controls_Manager::TEXT,
                            'default' => '',
                            'placeholder' => __( 'Type service title', 'medilac' ),
                            'dynamic' => [
                                    'active' => true,
                            ]
                    ]
            );
            
            
            $this->add_control(
                    'service_details',
                    [
                            'label' => __( 'Service Details', 'medilac' ),
                            'description' => 'Allowed html description', // could be render from function
                            'type' => Controls_Manager::TEXTAREA,
                            'placeholder' => __( 'Write something amazing about your service', 'medilac' ),
                            'rows' => 5,
                            'dynamic' => [
                                    'active' => true,
                            ]
                    ]
            );
            
            $this->add_control(
                    'title_tag',
                    [
                            'label' => __( 'Title HTML Tag', 'medilac' ),
                            'type' => Controls_Manager::CHOOSE,
                            'options' => [
                                    'h1'  => [
                                            'title' => __( 'H1', 'medilac' ),
                                            'icon' => 'eicon-editor-h1'
                                    ],
                                    'h2'  => [
                                            'title' => __( 'H2', 'medilac' ),
                                            'icon' => 'eicon-editor-h2'
                                    ],
                                    'h3'  => [
                                            'title' => __( 'H3', 'medilac' ),
                                            'icon' => 'eicon-editor-h3'
                                    ],
                                    'h4'  => [
                                            'title' => __( 'H4', 'medilac' ),
                                            'icon' => 'eicon-editor-h4'
                                    ],
                                    'h5'  => [
                                            'title' => __( 'H5', 'medilac' ),
                                            'icon' => 'eicon-editor-h5'
                                    ],
                                    'h6'  => [
                                            'title' => __( 'H6', 'medilac' ),
                                            'icon' => 'eicon-editor-h6'
                                    ]
                            ],
                            'default' => 'h2',
                            'toggle' => false,
                            'separator' => 'before',
                    ]
            );
            
            $this->add_responsive_control(
                    'align',
                    [
                            'label' => __( 'Alignment', 'medilac' ),
                            'type' => Controls_Manager::CHOOSE,
                            'options' => [
                                    'left' => [
                                            'title' => __( 'Left', 'medilac' ),
                                            'icon' => 'eicon-text-align-left',
                                    ],
                                    'center' => [
                                            'title' => __( 'Center', 'medilac' ),
                                            'icon' => 'eicon-text-align-center',
                                    ],
                                    'right' => [
                                            'title' => __( 'Right', 'medilac' ),
                                            'icon' => 'eicon-text-align-right',
                                    ],
                                    'justify' => [
                                            'title' => __( 'Justify', 'medilac' ),
                                            'icon' => 'eicon-text-align-justify',
                                    ],
                            ],
                            'toggle' => true,
                            'selectors' => [
                                    '{{WRAPPER}}' => 'text-align: {{VALUE}};'
                            ]
                    ]
            );
            
            $this->add_control(
                    'service_icon',
                    [
                            'type' => Controls_Manager::ICONS,
                            'label_block' => true,
                            'show_label' => false,
                    ]
            );
            
            $this->add_control(
                    'service_icon_spacing',
                    [
                            'label' => __( 'Icon Spacing', 'medilac' ),
                            'type' => Controls_Manager::SLIDER,
                            'default' => [
                                    'size' => 10
                            ],
                            'condition' => [
                                    'service_icon[value]!' => ''
                            ],
//				'selectors' => [
//					'{{WRAPPER}} .medilac-btn--icon-before .medilac-btn-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
//					'{{WRAPPER}} .medilac-btn--icon-after .medilac-btn-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
//				],
                    ]
            );
            
            $this->add_control(
                    'customize',
                    [
                            'label' => __( 'Want To Customize?', 'medilac' ),
                            'type' => Controls_Manager::SWITCHER,
                            'label_on' => __( 'Yes', 'medilac' ),
                            'label_off' => __( 'No', 'medilac' ),
                            'return_value' => 'yes',
                            'style_transfer' => true,
                    ]
            );
            $this->add_control(
                    'service_icon_size',
                    [
                            'label'          => __('Font Size', 'medilac'),
                            'type'           => Controls_Manager::SLIDER,
                            'selectors'      => [
                                    '{{WRAPPER}} .service-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                            ],
                            'default' => [
                                    'size' => 30
                            ],
                            'condition' => [
                                    'customize' => 'yes'
                            ],
                            'style_transfer' => true,
                    ]
            );
            $this->start_controls_tabs(
                    '_tab_icon_colors',
                    [
                            'condition' => ['customize' => 'yes']
                    ]
            );
            $this->start_controls_tab(
                    '_tab_icon_normal',
                    [
                            'label' => __( 'Normal', 'medilac' ),
                    ]
            );

            $this->add_control(
                    'color',
                    [
                            'label' => __( 'Text Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-icon' => 'color: {{VALUE}}',
				],
                            'condition' => ['customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->add_control(
                    'bg_color',
                    [
                            'label' => __( 'Background Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-icon' => 'background-color: {{VALUE}}',
				],
                            'condition' => ['customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->end_controls_tab();
            $this->start_controls_tab(
                    '_tab_icon_hover',
                    [
                            'label' => __( 'Hover', 'medilac' ),
                    ]
            );

            $this->add_control(
                    'hover_color',
                    [
                            'label' => __( 'Text Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item:hover .service-icon, {{WRAPPER}} .service-item:focus .service-icon' => 'color: {{VALUE}}',
				],
                            'condition' => ['customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->add_control(
                    'hover_bg_color',
                    [
                            'label' => __( 'Background Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item:hover .service-icon, {{WRAPPER}} .service-item:focus .service-icon' => 'background-color: {{VALUE}}',
				],
                            'condition' => ['customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

//            $this->add_control(
//                    'hover_border_color',
//                    [
//                            'label' => __( 'Border Color', 'medilac' ),
//                            'type' => Controls_Manager::COLOR,
//				'selectors' => [
//					'{{WRAPPER}} .service-icon:hover, {{WRAPPER}} .service-icon:focus' => 'border-color: {{VALUE}}',
//				],
//                            'condition' => ['customize' => 'yes'],
//                            'style_transfer' => true,
//                    ]
//            );

            $this->end_controls_tab();
            $this->end_controls_tabs();
            
            
            
            
            
            $this->end_controls_section();
            
            $this->start_controls_section(
                    '_section_button',
                    [
                            'label' => __( 'Details Button', 'medilac' ),
                            'tab' => Controls_Manager::TAB_CONTENT,
                    ]
            );
            
            $this->add_control(
                    'show_details_button',
                    [
                            'label' => __( 'Show Button', 'medilac' ),
                            'type' => Controls_Manager::SWITCHER,
                            'label_on' => __( 'Show', 'medilac' ),
                            'label_off' => __( 'Hide', 'medilac' ),
                            'return_value' => 'yes',
                            'default' => '',
                            'style_transfer' => true,
                    ]
            );
            
            $this->add_control(
                    'button_text',
                    [
                            'label' => __( 'Text', 'medilac' ),
                            'type' => Controls_Manager::TEXT,
                            'default' => __( 'Show Details', 'medilac' ),
                            'placeholder' => __( 'Type button text here', 'medilac' ),
                            'label_block' => true,
                            'dynamic' => [
                                    'active' => true,
                            ],
                            'condition' => [
                                    'show_details_button' => 'yes',
                            ]
                    ]
            );

            $this->add_control(
                    'button_link',
                    [
                            'label' => __( 'Link', 'medilac' ),
                            'type' => Controls_Manager::URL,
                            'placeholder' => 'https://example.com',
                            'dynamic' => [
                                    'active' => true,
                            ],
                            'condition' => [
                                    'show_details_button' => 'yes',
                            ],
                            'default' => [
                                    'url' => '#',
                            ]
                    ]
            );

            $this->add_control(
                    'button_icon',
                    [
                            'type' => Controls_Manager::ICONS,
                            'label_block' => true,
                            'show_label' => false,
                            'condition' => [
                                    'show_details_button' => 'yes',
                            ]
                    ]
            );
            
            $this->add_control(
                    'button_icon_spacing',
                    [
                            'label' => __( 'Icon Spacing', 'medilac' ),
                            'type' => Controls_Manager::SLIDER,
                            'default' => [
                                    'size' => 10
                            ],
                            'condition' => [
                                    'show_details_button' => 'yes',
                                    'button_icon[value]!' => ''
                            ],
//				'selectors' => [
//					'{{WRAPPER}} .medilac-btn--icon-before .medilac-btn-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
//					'{{WRAPPER}} .medilac-btn--icon-after .medilac-btn-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
//				],
                    ]
            );
            
            $this->add_control(
                    'button_customize',
                    [
                            'label' => __( 'Want To Customize?', 'medilac' ),
                            'type' => Controls_Manager::SWITCHER,
                            'label_on' => __( 'Yes', 'medilac' ),
                            'label_off' => __( 'No', 'medilac' ),
                            'return_value' => 'yes',
                            'style_transfer' => true,
                    ]
            );
//            $this->add_control(
//                    'service_icon_size',
//                    [
//                            'label'          => __('Font Size', 'medilac'),
//                            'type'           => Controls_Manager::SLIDER,
//                            'selectors'      => [
//                                    '{{WRAPPER}} .service-icon' => 'font-size: {{SIZE}}{{UNIT}};',
//                            ],
//                            'default' => [
//                                    'size' => 30
//                            ],
//                            'condition' => [
//                                    'customize' => 'yes'
//                            ],
//                            'style_transfer' => true,
//                    ]
//            );
            $this->start_controls_tabs(
                    '_button_text_colors',
                    [
                            'condition' => ['button_customize' => 'yes']
                    ]
            );
            $this->start_controls_tab(
                    '_button_text_normal',
                    [
                            'label' => __( 'Normal', 'medilac' ),
                    ]
            );

            $this->add_control(
                    '_button_text_normal_color',
                    [
                            'label' => __( 'Text Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn.v5' => 'color: {{VALUE}}',
				],
                            'condition' => ['button_customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->add_control(
                    '_button_text_normal_bg_color',
                    [
                            'label' => __( 'Background Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn.v5' => 'background-color: {{VALUE}}',
				],
                            'condition' => ['button_customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->end_controls_tab();
            $this->start_controls_tab(
                    '_button_text_hover',
                    [
                            'label' => __( 'Hover', 'medilac' ),
                    ]
            );

            $this->add_control(
                    '_button_text_hover_color',
                    [
                            'label' => __( 'Text Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item:hover .btn.v5, {{WRAPPER}} .service-item:focus .btn.v5' => 'color: {{VALUE}}',
				],
                            'condition' => ['button_customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->add_control(
                    '_button_text_hover_bg_color',
                    [
                            'label' => __( 'Background Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item:hover .btn.v5, {{WRAPPER}} .service-item:focus .btn.v5' => 'background-color: {{VALUE}}',
				],
                            'condition' => ['button_customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );
            $this->add_control(
                    '_button_text_hover_border_color',
                    [
                            'label' => __( 'Border Color', 'medilac' ),
                            'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item:hover .btn.v5, {{WRAPPER}} .service-item:focus .btn.v5' => 'border-color: {{VALUE}}',
				],
                            'condition' => ['button_customize' => 'yes'],
                            'style_transfer' => true,
                    ]
            );

            $this->end_controls_tab();
            $this->end_controls_tabs();

            $this->end_controls_section();
            
        }
        
        protected function button_renderer( $args ){
            $settings = $this->get_settings_for_display();
            
            $args = wp_parse_args( $args, [
                    'old_icon'   => 'button_icon',
                    'new_icon'   => 'button_selected_icon',
                    'text'       => 'button_text',
                    'link'       => 'button_link',
                    'class'      => 'medilac-btn medilac-btn--link',
                    'text_class' => 'medilac-btn-text',
            ] );
            
            $button_text = isset( $settings[ $args['text'] ] ) ? $settings[ $args['text'] ] : '';
            $has_new_icon = ( ! empty( $settings[ $args['new_icon'] ] ) && ! empty( $settings[ $args['new_icon'] ]['value'] ) ) ? true : false;
            $button_new_icon = ( ! empty( $settings[ $args['new_icon'] ] ) && ! empty( $settings[ $args['new_icon'] ]['value'] ) ) ? $settings[ $args['new_icon'] ]['value'] : false;
            $has_old_icon = ! empty( $settings[ $args['old_icon'] ] ) ? true : false;
            if ( empty( $button_text ) && ! $has_new_icon && ! $has_old_icon ) {
                    return;
            }
            $this->add_inline_editing_attributes( $args['text'], 'none' );
            $this->add_render_attribute( $args['text'], 'class', $args['text_class'] );

            $this->add_render_attribute( 'button', 'class', $args['class'] );
            $this->add_link_attributes( 'button', $settings[ $args['link'] ] );
            
            if ( $button_text && ( empty( $has_new_icon ) && empty( $has_old_icon ) ) ) :
                    printf( '<a %1$s>%2$s</a>',
                            $this->get_render_attribute_string( 'button' ),
                            sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( $args['text'] ), esc_html( $button_text ) )
                    );
            elseif ( empty( $button_text ) && ( ! empty( $has_old_icon ) || ! empty( $has_new_icon ) ) ) : ?>
                    <a <?php $this->print_render_attribute_string( 'button' ); ?>><?php // medilac_render_button_icon( $settings, $args['old_icon'], $args['new_icon'] ); ?></a>
            <?php elseif ( $button_text && ( ! empty( $has_old_icon ) || ! empty( $has_new_icon ) ) ) :
                    
                    $this->add_render_attribute( 'button', 'class', 'btn v5 mt-3' );
                    $button_text = sprintf( '<span %1$s>%2$s</span>', $this->get_render_attribute_string( $args['text'] ), esc_html( $button_text ) );
                    ?>
                    <a <?php $this->print_render_attribute_string( 'button' ); ?>><?php echo $button_text; ?> <i class="<?php echo esc_html( $button_new_icon ) ?>"></i></a>
                    <?php
                    
            endif;
        }
        
        /**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
            $settings = $this->get_settings_for_display();
            
            $show_button = false;
            if ( ! empty( $settings['show_details_button'] ) && $settings['show_details_button'] === 'yes'  ) {
                    $show_button = true;
            }
            
            $this->add_inline_editing_attributes( 'service', 'basic' );
            $this->add_render_attribute( 'title', 'class', 'service-name' );
                
            $this->add_inline_editing_attributes( 'service_details', 'basic' );
            $this->add_render_attribute( 'service_details', 'class', 'service-details' );
//            var_dump(empty( $settings['service_icon']['value']) );
//            var_dump($settings);
            ?>
            <div class="service-item">
                <?php if( ! empty( $settings['service_icon']['value']) ): ?>
                <div class="service-icon bg-blue">
                    <i class="<?php echo esc_attr( $settings['service_icon']['value']); ?>"></i>
                </div>
                <?php endif; ?>
                <div class="service-info">
                    <?php if ( $settings['service_title'] ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                    tag_escape( $settings['title_tag'] ),
                                    $this->get_render_attribute_string( 'service_title' ),
                                    wp_kses_post( $settings['service_title'] )
                            );
                    endif; ?>
                    
                    <?php if ( $settings['service_details'] ) : ?>
                            <div <?php $this->print_render_attribute_string( 'service_details' ); ?>>
                                <p class="para"><?php echo wp_kses_post( $settings['service_details'] ); ?></p>
                            </div>
                    <?php endif; ?>
                    
                    <?php
                        
                    if ( $show_button ) {
                            $this->button_renderer( [ 'new_icon' => 'button_icon', 'old_icon' => '' ] );
                    }
                    ?>
                </div>
            </div>
            <?php
        }
}


<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Gallery extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_gallery';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Gallery Section', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Gallery';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-device-tablet';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'gallery', 'gallerys', 'portfolio', 'portfolios' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Register Item
        $this->register_content_controls();
        // Heading Style
        $this->register_heading_style_controls();
        // Register Items title
        $this->register_item_title();
    }
    
    /**
     * Register Gallery Items General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'gallery_content_items',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'gallery_style',
            [
                'label'     => esc_html__( 'Gallery Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }


    /**
     * Register Gallery Items Content Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_content_controls(){
        $this->start_controls_section(
                'gallery_items_settings',
            [
                    'label'     => __( 'Gallery Items', 'medilac' ),
            ]
        );
        $this->add_control(
             'items',
            [
                'label'     => esc_html__( 'Galleries', 'medilac' ),
                'type'      => Controls_Manager::REPEATER,
                'default'   => [
                    [
                        'image'             => array(
                                'url'       => Utils::get_placeholder_image_src(),
                        ),
                       
                    ],
                    [
                        'image'             => array(
                         'url'       => Utils::get_placeholder_image_src(),
                        ),
                    ],
                                        [
                        'image'             => array(
                                'url'       => Utils::get_placeholder_image_src(),
                        ),
                    ],
                ],
                'fields'        => [
                    [
                        'name'          => 'image',
                        'label'         => __( 'Select Image', 'medilac' ),
                        'type'          => Controls_Manager::MEDIA,
                        'return_value'  => 'yes',
                        'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'name'          => 'sub_title',
                        'label'         => __( 'Sub Title', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block'   => TRUE, 
                    ],
                    [
                        'name'          => 'title',
                        'label'         => __( 'Title', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block'   => TRUE, 
                    ],
                    [
                        'name'          => 'item_url',
                        'label'         => __( 'Button URL:', 'medilac' ),
                        'type'          => Controls_Manager::URL,
                        'label_block'   => TRUE, 
                    ],
                ],
            ]
        );
	$this->end_controls_section();
    }
    

    /**
     * Gallery Sub heading.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_style_controls(){
	    $this->start_controls_section(
	            'item_sub_title_style',
                [
                    'label'    => __( 'Items Sub Title', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'item_sub_title_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'item_sub_title_ty',
                'selector' => '{{WRAPPER}} .medilac-seciton .gallery-info-title span',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'item_sub_titles_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'item_sub_title_margins',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_sub_title_borders',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .medilac-seciton .gallery-info-title span',
            ]
        );
        $this->add_control(
            'items_sub_title',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title span' => 'text-align: {{VALUE}}',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Price Items Title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_item_title(){
	    $this->start_controls_section(
	            'item_title',
                [
                    'label'     => esc_html__( 'Item Title', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'gallery_title', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title p' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'gallery_item_title',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'gallery_item_title',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-seciton .gallery-info-title p',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'gallery_items_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .medilac-seciton .gallery-info-title p',
            )
        );
        $this->add_responsive_control(
            'gallery_items_title',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}}.medilac-seciton .gallery-info-title p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'gallery_items_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'gallery_ites_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'gallery_items_shadow',
                'selector' => '{{WRAPPER}} .medilac-seciton .gallery-info-title p',
            )
        );
        $this->add_control(
            'gallery_items',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-seciton .gallery-info-title p' => 'text-align: {{value}};',
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );
	$this->end_controls_section();
    }
 
    /**
     * Get Gallery Items
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function get_gallery_items(){
        $settings   = $this->get_settings_for_display();
        $items      = isset( $settings['items'] ) ? $settings['items'] : '';
        foreach( (array) $items as $item ){ 
            $target            = $item['item_url']['is_external'] ? ' target="_blank"' : '';
            $nofollow          = $item['item_url']['nofollow'] ? ' rel="nofollow"' : '';
            ?>
        <div class="gallery-item">
            <?php if(!empty( $item['image']['url'] )) : ?>
            <img src="<?php echo esc_url( $item['image']['url'] );?>" alt="<?php esc_html_e('Image', 'medilac')?>">
            <?php endif; ?>
            <?php if(!empty( $item['sub_title'] ) || !empty( $item['title'] ) || !empty( $item['item_url']['url'] )) : ?>
            <div class="gallery-item-info">
              <div class="gallery-info-title">
                    <?php if(!empty( $item['sub_title']) ) : ?>
                    <span><?php echo esc_html( $item['sub_title'] );?></span>
                    <?php endif; ?>
                     <?php if(!empty($item['title'])) : ?>
                    <p><?php echo esc_html( $item['title'] );?></p>
                    <?php endif; ?>
              </div>
              
              <?php if(!empty( $item['item_url']['url']) ) : ?>
              <div class="gallery-info-link">
                  <a <?php echo esc_attr( "'. $target .' ' . $nofollow . '" );?> href="<?php echo esc_url( $item['item_url']['url'] );?>"><i class="fas fa-plus"></i></a>
              </div>
              <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>            
        <?php }
        }    

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        if( isset( $settings['gallery_style'] ) && '1' == $settings['gallery_style'] ){?>
        <!-- What we do Start -->
        <section class="page-template-template-home3 gallery-area v1 medilac-seciton">
          <div class="row">
            <div class="gallery-item-wrap">
                 <?php $this->get_gallery_items();?>
            </div>
          </div>
        </section>
        <!-- What we do End -->
        <?php }else {?>
        <!-- Gallery section section start -->
        <section class="gallery-area v1 medilac-seciton">
            <div class="medilac-home-container">
                   <div class="row">
                       <div class="gallery-item-wrap">
                           <?php $this->get_gallery_items();?>
                       </div>
                   </div>
                </div>
            </div>
        </section>
        <!-- Gallery section section end -->
        <?php }
    }
    
    protected function _content_template() {}
    
}
<?php
return [
    'Medilac_Element_Pricing' => [
        'name'      =>  'medilac_element_pricing', //It will be optional, if not set, will get from Main Index.
        'icon'      =>  'eicon-elementor-circle',
        'title'     =>  __( 'Price Table', 'medilac' ),
        'category'  =>  ['basic'],
        'query'     => []
    ],
];
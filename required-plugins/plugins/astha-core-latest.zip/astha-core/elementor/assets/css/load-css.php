<?php

//wp_enqueue_style('temp-home', MEDILAC_CORE_ELEMENTOR_BASE_URL . 'assets/css/temp-home.css', array(), '1.0.0', 'all');

add_action( 'wp_enqueue_scripts', function(){
//    wp_enqueue_style('temp-home', MEDILAC_CORE_ELEMENTOR_BASE_URL . 'assets/css/temp-home.css', array(), '1.0.0', 'all');
},9999 );
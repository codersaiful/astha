;
(function ($, w) {
    "use strict";

    //Counter animation
    $(document).ready(function ($) {

     
    
    });
}(jQuery, window));
<?php

/**
 * Register Custom Post Type Header_Footer
 * Actually We want to make Custom Header Footer
 * for our Medilac Theme.
 */
function medilac_core_register_header_footer_post() {

	/**
	 * Post Type: Header & Footer.
	 */

	$labels = [
		"name" => __( "Header & Footer", "medilac" ),
		"singular_name" => __( "Header & Footer", "medilac" ),
		"menu_name" => __( "Header & Footer", "medilac" ),
		"all_items" => __( "All Header & Footer", "medilac" ),
		"add_new" => __( "Add new", "medilac" ),
		"add_new_item" => __( "Add new Header & Footer", "medilac" ),
		"edit_item" => __( "Edit Header & Footer", "medilac" ),
		"new_item" => __( "New Header & Footer", "medilac" ),
		"view_item" => __( "View Header & Footer", "medilac" ),
		"view_items" => __( "View Header & Footer", "medilac" ),
		"search_items" => __( "Search Header & Footer", "medilac" ),
		"not_found" => __( "No Header & Footer found", "medilac" ),
		"not_found_in_trash" => __( "No Header & Footer found in trash", "medilac" ),
		"parent" => __( "Parent Header & Footer:", "medilac" ),
		"featured_image" => __( "Featured image for this Header & Footer", "medilac" ),
		"set_featured_image" => __( "Set featured image for this Header & Footer", "medilac" ),
		"remove_featured_image" => __( "Remove featured image for this Header & Footer", "medilac" ),
		"use_featured_image" => __( "Use as featured image for this Header & Footer", "medilac" ),
		"archives" => __( "Header & Footer archives", "medilac" ),
		"insert_into_item" => __( "Insert into Header & Footer", "medilac" ),
		"uploaded_to_this_item" => __( "Upload to this Header & Footer", "medilac" ),
		"filter_items_list" => __( "Filter Header & Footer list", "medilac" ),
		"items_list_navigation" => __( "Header & Footer list navigation", "medilac" ),
		"items_list" => __( "Header & Footer list", "medilac" ),
		"attributes" => __( "Header & Footer attributes", "medilac" ),
		"name_admin_bar" => __( "Header & Footer", "medilac" ),
		"item_published" => __( "Header & Footer published", "medilac" ),
		"item_published_privately" => __( "Header & Footer published privately.", "medilac" ),
		"item_reverted_to_draft" => __( "Header & Footer reverted to draft.", "medilac" ),
		"item_scheduled" => __( "Header & Footer scheduled", "medilac" ),
		"item_updated" => __( "Header & Footer updated.", "medilac" ),
		"parent_item_colon" => __( "Parent Header & Footer:", "medilac" ),
	];

	$args = [
		"label" => __( "Header & Footer", "medilac" ),
		"labels" => $labels,
		"description" => __( "This post is for Medilac Header and Footer", "medilac" ),
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => false,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => true,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "header-footer", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-hammer",
		"supports" => [ "title", "editor" ],
	];

	register_post_type( "header_footer", $args );
}

add_action( 'init', 'medilac_core_register_header_footer_post' );

/**
 * Add Submenu Under Theme's medilac
 * Menu name: Header and Footer
 * 
 * We also add this menu Feature to our Plugin UltraAddons
 * and post type will also same: 'header_footer'
 */
function medilac_core_add_submenu(){
    $page_title = $menu_title = esc_html__( 'Header & Footer', 'medilac' );
    $capability = 'edit_themes';
    $menu_slug = admin_url( 'edit.php?post_type=header_footer' );
    add_submenu_page('medilac_welcome', $page_title, $menu_title, $capability, $menu_slug, '', 3 );
//    add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function, $position);
}
add_action( 'admin_menu', 'medilac_core_add_submenu' );

function medilac_core_template_header_footer( $template_file ){

    if( ! is_singular() ){
        return $template_file;
    }
    $type = get_post_type();
    if( $type == 'header_footer' ){
        $template = MEDILAC_CORE_BASE_DIR . 'templates/header-footer.php';
        return is_file( $template ) ? $template : $template_file;
    }
   
    return $template_file;
}
add_filter( 'template_include', 'medilac_core_template_header_footer' );
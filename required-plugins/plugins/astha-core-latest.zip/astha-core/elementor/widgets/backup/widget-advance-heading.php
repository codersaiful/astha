<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Advance_Heading extends Widget_Base{
    
    /**
     * Widget Pricing Table
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_advance_heading';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Advance Heading', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Advance_Heading';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-heading';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'heading', 'header', 'title' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Advance Heading Style
        $this->register_general_style();
        // Register pricing style
        $this->register_general_controls();
       // General Settings
        $this->register_heading_align_style();
        // Register Sub Heading
        $this->register_sub_heading_style_controls();
        // Heading Style
        $this->register_heading_style_controls();

    }
    
        /**
     * Register Icon Box General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_style(){
        $this->start_controls_section(
            'heading_style_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'heading_style',
            [
                'label'     => esc_html__( 'Heading Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Price Table General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'advance_heading_settings',
            [
                'label'     => esc_html__( 'Content', 'medilac' ),
            ]
        );
        $this->add_control(
            'advance_sub_heading',
                [
                    'label'     => esc_html__( 'Sub Heading', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'placeholder'   => __( 'Our Services', 'medilac' ),
                    'label_block'   => TRUE,
                ]
        );
        $this->add_control(
            'advance_heading',
                [
                    'label'     => esc_html__( 'Heading', 'medilac' ),
                    'type'          => Controls_Manager::TEXTAREA,
                    'label_block'   => TRUE,
                    'placeholder'   => __( 'We Provide Best Services sFor Your Health', 'medilac' ),
                ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register heading style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_align_style(){
	    $this->start_controls_section(
	            'advance_heading_general_setting',
                [
                    'label'    => __( 'General Settings', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_responsive_control(
            'heading_general_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-title.medilac-advance-heading, .section-title.v1.medilac-advance-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_tag_general_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-title.medilac-advance-heading, .section-title.v1.medilac-advance-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'heading_tag_general_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-title.medilac-advance-heading, .section-title.v1.medilac-advance-heading' => 'text-align: {{VALUE}}',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Register Sub Heading
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_sub_heading_style_controls(){
	    $this->start_controls_section(
	            'advance_sub_heading_style_setting',
                [
                    'label'    => __( 'Sub Heading', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'sub_heading_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing, .section-title.v1.medilac-advance-heading span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'sub_border_heading_color',
            [
                'label'     => __( 'After Border Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing:after, .section-title.v1.medilac-advance-heading span:before, .section-title.v1.medilac-advance-heading span:after' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'sub_heading_typography',
                'selector' => '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing, .section-title.v1.medilac-advance-heading span',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'sub_header_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing, .section-title.v1.medilac-advance-heading span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'sub_header_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing, .section-title.v1.medilac-advance-heading span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'sub_heading_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .content-title .medilac-sub-heading.elementor-inline-editing, .section-title.v1.medilac-advance-heading span',
            ]
        );
        $this->end_controls_section();
    }
   

    /**
     * Register heading style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_style_controls(){
	    $this->start_controls_section(
	            'advance_heading_style_setting',
                [
                    'label'    => __( 'Heading', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'heading_tag_colors',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .content-title span.medilac-sub-heading, .section-title.v1.medilac-advance-heading h3.medilac-heading' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_tag_typography',
                'selector' => '{{WRAPPER}} .pricing-box-item .pricing-icon .medilac-price-table-heading, .section-title.v1.medilac-advance-heading h3.medilac-heading',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'heading_tag_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .pricing-box-item .pricing-icon .medilac-price-table-heading, .section-title.v1.medilac-advance-heading h3.medilac-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'heading_tag_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .pricing-box-item .pricing-icon .medilac-price-table-heading, .section-title.v1.medilac-advance-heading h3.medilac-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'heading_tag_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .pricing-box-item .pricing-icon .medilac-price-table-heading, .section-title.v1.medilac-advance-heading h3.medilac-heading',
            ]
        );
        $this->end_controls_section();
    }
    
    

    /**
     * Get Sub Heading Content.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function get_sub_heading_content(){
        $settings       = $this->get_settings_for_display();
        $advance_sub_heading        = isset( $settings['advance_sub_heading'] ) ? $settings['advance_sub_heading'] : '';
        if(!empty( $advance_sub_heading )) : ?> 
            <span class="medilac-sub-heading elementor-inline-editing"><?php echo esc_html( $advance_sub_heading );?></span>
        <?php endif;
    }
    
    /**
     * Get Heading Content.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function get_heading_content(){
        $settings       = $this->get_settings_for_display();
        $advance_heading        = isset( $settings['advance_heading'] ) ? $settings['advance_heading'] : '';
        if(!empty( $advance_heading )) : ?> 
            <h3 class="medilac-heading elementor-inline-editing"><?php echo esc_html( $advance_heading );?></h3>
        <?php endif;
    }
    
  

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings           = $this->get_settings_for_display();
        if( isset( $settings['heading_style'] ) && '1' == $settings['heading_style'] ){?>
        <div class="content-title medilac-advance-heading">
            <?php $this->get_sub_heading_content(); ?>
            <?php $this->get_heading_content();?>
        </div> 
        <?php }else{ ?>
        <div class="section-title v1 medilac-advance-heading">
          <?php $this->get_sub_heading_content(); ?>
          <?php $this->get_heading_content();?>
        </div>
        <?php }
    }
    
    protected function _content_template() {}
    
}
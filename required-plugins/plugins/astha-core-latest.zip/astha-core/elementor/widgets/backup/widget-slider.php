<?php

//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Slider extends Widget_Base{
    
	/**
	 * Get Slider Section
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'medilac_widget_slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider Section', 'medilac' );
	}
        
        public function get_custom_help_url() {
                return 'https://example.com/Medilac_Widget_Slider';
        }
	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slider-full-screen';
	}
        public function get_keywords() {
                return [ 'slider', 'owl-carosel', 'carosel', 'sliders', 'medilac' ];
        }
	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'medilac' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
    protected function _register_controls() {
        /**
        * Slider Section.
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'slider_section_content',
            [
                'label' => esc_html__( 'Medilac Slider', 'medilac' )
            ]
        );
        /**
        * Select your slider style here.
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->add_control(
            'style',
            [
                'label'         => esc_html__( 'Choose Style', 'medilac' ),
                'type'          => Controls_Manager::SELECT,
                'default'       => 'style1',
                'options'       => [
                    'style1' => esc_html__( 'Style 1', 'medilac' ),
                    'style2' => esc_html__( 'Style 2', 'medilac' ),
                    'style3' => esc_html__( 'Style 3', 'medilac' ),
                ]
            ]
        );
        $this->add_control(
            'sliders',
            [
                'label'         => esc_html__( 'Slider', 'medilac' ),
                'type'          => Controls_Manager::REPEATER,
                'condition'     => [
                    'style'     => 'style1',
                ],
                'fields'        => [
                    [
                        'name'          => 'title',
                        'label'         => esc_html__( 'Title', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'default'       => 'Best of Care <br> close to Home',
                        'label_block' => true,
                    ],
                    [
                        'name'          => 'sub_title',
                        'label'         => esc_html__( 'Subtitle', 'medilac' ),
                        'type'          => Controls_Manager::TEXTAREA,
                        'default'       => "Lorem Ipsum is simply dumy text of the printing &amp; typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1975, when an unknown printer",
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'item_btn1_text',
                        'label'         => esc_html__( 'Button Text', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'default'       => 'Book Appoinment',
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'slide_item_url',
                        'label'         => esc_html__( 'Button URl:', 'medilac' ),
                        'type'          => Controls_Manager::URL,
                        'label_block'   => true,
                        'placeholder'   => esc_html__( 'http://your-link.com','medilac' ),
                    ],
                    [
                        'name'          => 'image1',
                        'label'         => esc_html__( 'Add Image', 'medilac' ),
                        'type'          => Controls_Manager::MEDIA,
                        'default'       => [
                            'url'       => Utils::get_placeholder_image_src(),
                        ],
                        'label_block'   => true,
                    ],
           
                ]
            ]
        );
        $this->add_control(
            'slider2',
            [
                'label'         => esc_html__( 'Slider', 'medilac' ),
                'type'          => Controls_Manager::REPEATER,
                'condition'     => [
                    'style'     => ['style3', 'style2'],
                ],
                'default'       => [
                    [
                        'sub_title'     => 'Welcome To Medilack CENTRAL HOSPITAL',
                        'title'         => 'Most Trusted Health <br> Partner For Life',
                        'item_btn2_text'    => 'Book Appoinment',
                        'image1'            => [
                           'url'       => Utils::get_placeholder_image_src(),
                        ]
                    ]
                ],
                'fields'        => [
                    [
                        'name'          => 'sub_title',
                        'label'         => esc_html__( 'Subtitle', 'medilac' ),
                        'type'          => Controls_Manager::TEXTAREA,
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'title',
                        'label'         => esc_html__( 'Title', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name'          => 'item_btn2_text',
                        'label'         => esc_html__( 'Button Text', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'item_btn2_url',
                        'label'         => esc_html__( 'Button URl:', 'medilac' ),
                        'type'          => Controls_Manager::URL,
                        'label_block'   => true,
                        'placeholder'   => esc_html__( 'http://your-link.com','medilac' ),
                    ],
                    [
                        'name'          => 'image1',
                        'label'         => esc_html__( 'Add Image', 'medilac' ),
                        'type'          => Controls_Manager::MEDIA,
                        'label_block'   => true,
                    ],
                ]
            ]
        );
        $this->end_controls_section();
        
        /**
        * Slider Title Style
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'slider_title',
            [
                'label'     => esc_html__( 'Title', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'slider_title_margin',
            [
                'label' => __( 'Margin', 'medilac' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text h1, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'slider_title_padding',
            [
                'label' => __( 'Padding', 'medilac' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text h1, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'slider_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text h1, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1',
            ]
        );
        $this->add_control(
            'slider_title_color',
            [
                'label' => __( 'Title Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text h1, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'slider_btn_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text h1 .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text h1' => 'text-align: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
        
        /**
        * Slider Subtitle Style
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'slider_sub_title',
            [
                'label'     => esc_html__( 'Sub Title', 'medilac' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'slider_sub_title_margin',
            [
                'label' => __( 'Margin', 'medilac' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text span, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'slider_sub_title_padding',
            [
                'label' => __( 'Padding', 'medilac' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text span, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'slider_sub_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .page-template-template-home4 .medilac-home-container .hero-text span, .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para',
            ]
        );
        $this->add_control(
            'slider_sub_title_color',
            [
                'label' => __( 'Sub Title Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para, .page-template-template-home4 .medilac-home-container .hero-text span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'slider_sub_title_shadow',
                'label' => __( 'Sub title Shadow', 'medilac' ),
                'selector' => '{{WRAPPER}} .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para, .page-template-template-home4 .medilac-home-container .hero-text span',
            ]
        );
        $this->add_control(
            'slider_btn1_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors'     => [
                    '{{WRAPPER}} .page-template-template-home3 .hero-slider-item .hero-content-wrap .hero-text .hero-subheading, section.hero-slider-area .hero-slider-item .hero-content-wrap .hero-text p.para, .page-template-template-home4 .medilac-home-container .hero-text span' => 'text-align: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
        
        /**
        * Register Button style here.
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_section(
            'section_slider_style',
            [
                'label'      => __( 'Button', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->start_controls_tabs( 'slider_slider_btn' );
        $this->start_controls_tab(
            'tab_button_content_normal',
            [
                'label'  => esc_html__( 'Normal', 'medilac' )
            ]
        );
        $this->add_control(
            'slider_slider_btn_normal_', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'slider_slider_btn_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'slider_slider_btn_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'slider_table_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3',
            )
        );
        $this->add_responsive_control(
            'slider_slider_btn_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'slider_slider_btn_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'slider_table_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'slider_table_shadow',
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3',
            )
        );
        $this->end_controls_tab();
        
        /**
        * Slider Button Hover Style
        * 
        * @access protected
        * 
        * @since 1.0.0
        */
        $this->start_controls_tab(
            'slider_table_content_hover',
            [
                'label' => esc_html__( 'Hover', 'medilac' ),
            ]
        );
        $this->add_control(
            'button_label_hover',
            array(
                'label'       => esc_html__( 'Button Label Color', 'medilac' ),
                'type'        => Controls_Manager::COLOR,
                'selectors'	 => [
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover' => 'color: {{VALUE}};'
                ],
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'hover_slider_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'slider_table_hover_background',
                'label' => __( 'Background', 'medilac' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'slider_normal_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover',
            )
        );
        $this->add_responsive_control(
            'hover_button_slider_table_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'hover_button_slider_table_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'hover_border_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'hover_box_shadow',
                'selector' => '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3:hover',
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control(
            'price_btn_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors'     => [
                    '{{WRAPPER}} .hero-slider-item .hero-content-wrap .btn.v3' => 'text-align: {{VALUE}};',
                ],
                'toggle' => true,
            ]
        );

        $this->end_controls_section();
    
        /**
        * Show Control Pagination
        * 
        * @access protected
        * 
        * @since 1.0.0
        */       
        $this->start_controls_section(
            'slider_control',
            [
                'label' => __( 'Control', 'medilac' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'show_pagination',
            [
                'label' => __( 'Show Pagination', 'medilac' ),
                'type'  => Controls_Manager::SWITCHER,
                'label_on'  => __( 'Show', 'medilac' ),
                'label_off' => __( 'Hide', 'medilac' ),
                'default'   => 'yes',
                'return_value'  => 'yes',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render( ) {
        $settings  = $this->get_settings_for_display();
        $slider    = isset( $settings['sliders'] ) ? $settings['sliders'] : '';
        $slider2   = isset( $settings['slider2'] ) ? $settings['slider2'] : '';
        $show_pagination    = isset( $settings['show_pagination'] ) ? $settings['show_pagination'] : '';
        if( isset( $settings['style'] ) && 'style1' == $settings['style'] ){?>
        <!-- your code start here -->
         <!-- Hero slider section start -->
         <section class="hero-slider-area">
             <div class="swiper-container hero-slider">
                 <div class="swiper-wrapper">
                     <?php foreach($slider as $slide){?>
                     <div class="swiper-slide">
                         <div class="hero-slider-item" style="background-image: url(<?php echo esc_url( $slide['image1']['url'] );?>);">
                                <div class="medilac-home-container">
                                    <div class="row">
                                        <div class="hero-content-wrap">
                                            <div class="hero-text">

                                                <?php if(!empty( $slide['title'] )) : ?>
                                                <h1><?php echo wp_kses_post( $slide['title'] );?></h1>
                                                <?php endif; ?>

                                                <?php if(!empty( $slide['sub_title'] )) : ?>
                                                <p class="para"><?php echo wp_kses_post( $slide['sub_title'] );?></p>
                                                <?php endif; ?>
                                                
                                                <?php 
                                                $slide_item_url = isset( $slide['slide_item_url']['url'] ) ? $slide['slide_item_url']['url'] : '';
                                                $target  = isset($slide['slide_item_url']['is_external']) ? 'target="_blank"' : '';
                                                $nofollow = isset($slide['slide_item_url']['nofollow']) ? 'rel="nofollow"' : '';
                                                ?>
                                                <?php if( !empty( $slide_item_url ) ) : ?>
                                                <div class="hero-btn">
                                                    <a class="btn v3" <?php echo esc_attr( $target );?> <?php echo esc_attr( $nofollow ); ?> href="<?php echo esc_url( $slide_item_url );?>"><?php echo esc_html( $slide['item_btn1_text'] ); ?></a>
                                                </div>
                                                <?php endif;?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                     </div>                     
                     <?php } ?>
                 </div>
                 <?php if('yes' == $show_pagination) : ?>
                 <!-- Add Pagination -->
                 <div class="swiper-pagination"></div>
                 <?php endif; ?>
             </div>
         </section>
         <!-- Hero slider section end -->           
       <?php }elseif('style2' == $settings['style']){ ?>   
        <!-- your code start here -->
          <!-- Hero slider section start -->
          <section class="page-template-template-home3 hero-slider-area">
            <div class="swiper-container hero-slider-3">
              <div class="swiper-wrapper">
                 <?php foreach($slider2 as $slide){?>
                    <div class="swiper-slide">
                      <div class="hero-slider-item"
                           style="background-image: url(<?php echo esc_url( $slide['image1']['url'] );?>);">
                        <div class="medilac-home-container">
                          <div class="row">
                            <div class="hero-content-wrap">
                              <div class="hero-text">
                                <?php if(!empty( $slide['sub_title'] )) : ?>
                                <span class="hero-subheading"><?php echo wp_kses_post( $slide['sub_title'] ); ?></span>
                                <?php endif; ?>
                                
                                <?php if(!empty( $slide['title'] )) : ?>
                                <h1><?php echo wp_kses_post( $slide['title'] );?></h1>
                                <?php endif; ?>
                                
                                <?php 
                                $item_btn2_url = isset( $slide['item_btn2_url']['url'] ) ? $slide['item_btn2_url']['url'] : '';
                                $target5  = isset( $slide['item_btn2_url']['is_external'] ) ? 'target="_blank"' : '';
                                $nofollow5 = isset( $slide['item_btn2_url']['nofollow'] ) ? 'rel="nofollow"' : '';
                                ?>
                                <?php if(!empty( $item_btn2_url )) : ?>
                                <div class="hero-btn">
                                    <a class="btn v3" href="<?php echo esc_url( $item_btn2_url );?>"><?php echo esc_html($slide['item_btn2_text']); ?></a>
                                </div>
                                <?php endif;?>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>                     
                 <?php } ?>  
              </div>
               <?php if( 'yes' == $show_pagination ) : ?>
              <!-- Add Arrow -->
              <div class="swiper-button-next"><i class="fas fa-angle-right"></i></div>
              <div class="swiper-button-prev"><i class="fas fa-angle-left"></i></div>
              <?php endif; ?>
            </div>
          </section>
          <!-- Hero slider section end -->
       <?php }elseif('style3' == $settings['style']){?>
            <!-- Hero Slider Section Start -->
            <section class="hero-slider-area page-template-template-home4">
              <div class="swiper-container hero-slider-4">
                <div class="swiper-wrapper">
                  <?php foreach($slider2 as $slide){?>
                    <div class="swiper-slide">
                        <div class="hero-slider-item"
                             style="background-image: url(<?php echo esc_url( $slide['image1']['url'] );?>);">
                          <div class="medilac-home-container">
                            <div class="row">
                              <div class="hero-content-wrap">
                                <div class="hero-text">
                                    <?php if(!empty( $slide['sub_title'] )) : ?>
                                    <span class="hero-subheading"><?php echo wp_kses_post( $slide['sub_title'] ); ?></span>
                                    <?php endif; ?>

                                    <?php if(!empty( $slide['title'] )) : ?>
                                    <h1><?php echo wp_kses_post( $slide['title'] );?></h1>
                                    <?php endif; ?>

                                    <?php if(!empty( $slide['item_btn2_text']) ) :
                                    $target4  = isset( $slide['item_btn2_url']['is_external'] ) ? 'target="_blank"' : '';
                                    $nofollow4 = isset( $slide['item_btn2_url']['nofollow'] ) ? 'rel="nofollow"' : '';
                                    ?>
                                    <div class="hero-btn">
                                        <a class="btn v3" <?php echo esc_attr($target4 );?> <?php echo esc_attr( $nofollow4 );?> href="<?php echo esc_url($slide['item_btn2_url']['url']);?>"><?php echo esc_html($slide['item_btn2_text']); ?></a>
                                    </div>
                                    <?php endif;?>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                   <?php }?> 
                </div>
                <?php if( 'yes' == $show_pagination ) : ?>
                <!-- Add Pagination -->
                <div class="swiper-pagination"></div>
                <?php endif; ?>
                </div>
            </section>
            <!-- Hero Slider Section Start -->
       <?php }
       }

    protected function _content_template() { }
}
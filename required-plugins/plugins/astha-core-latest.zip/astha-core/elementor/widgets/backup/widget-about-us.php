<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_About_Us extends Widget_Base{
    
    /**
     * Widget About Us
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_about_us';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'About Us', 'medilac' );
    }
  
    /**
     * Help URL
     *
     * @since 1.0.0
     *
     * @var int Widget Icon.
     */
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_About_Us';
    }
    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-meta-data';
    }
    
    /**
     * Get your widget name
     *
     * Retrieve oEmbed widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string keywords
     */
    public function get_keywords() {
        return [ 'medilac', 'about', 'aboutus', 'abouts' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register pricing style
        $this->register_general_controls();
        // Register About Us Image 
        $this->register_about_image();
        // Register About Us Ribbon Text
        $this->register_about_ribbon();
         // Register About Section title
        $this->register_about_section_title();
        // Register About us Contents
        $this->register_about_us_contents();
        // Register About Us Button
        $this->register_about_us_button();
        // Register Button
        $this->register_about_video_btn();
        // Sale Ribbon Style
        $this->register_ribbon_style();
        // Style of sub title
        $this->register_sub_title_style();
        // About us title style
        $this->register_about_title_style();
    }
    
    /**
     * Register About Us Settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'about_us_settings',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'about_style',
            [
                'label'     => esc_html__( 'About Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                    '3'         => esc_html__( 'Style 03', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get About us image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_image(){
        $this->start_controls_section(
            'about_us_image_settings',
            [
                'label'     => esc_html__( 'About Image', 'medilac' ),
            ]
        );
        $this->add_control(
            'about_image',
            [
                'label'     => __( 'Select Image', 'medilac' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url'       => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Get About Us Ribbon Content
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_ribbon(){
        $this->start_controls_section(
            'about_us_ribbon_settings',
            [
                'label'     => esc_html__( 'Ribbon Text', 'medilac' ),
                'condition'   => [
                    'about_style' => '1',
                ],
            ]
        );
        $this->add_control(
            'ribbon_content',
            [
                'label'     => __( 'Type Text here', 'medilac' ),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => '<p>45+</p><span>Years of <br> Experience</span>',
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register Section title and sub title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_section_title(){
        $this->start_controls_section(
                'about_us_heading_settings',
            [
                    'label'     => esc_html__( 'Section Title', 'medilac' ),
            ]
        );
       $this->add_control(
            'about_sub_title',
                [
                    'label'     => esc_html__( 'Sub Title', 'medilac' ),
                    'type'          => Controls_Manager::TEXT,
                    'default'   => __( 'About Us', 'medilac' ),
                ]
        );
        $this->add_control(
            'about_title',
                [
                    'label'     => esc_html__( 'Heading', 'medilac' ),
                    'type'          => Controls_Manager::TEXTAREA,
                    'default'   => __( 'Great Healthcare Solutions Since 25+ years', 'medilac' ),
                ]
        );
	$this->end_controls_section();
    }

    /**
     * Register About Us Contents
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_us_contents(){
        $this->start_controls_section(
            'about_us_contents',
            [
                'label'     => esc_html__( 'Content', 'medilac' ),
            ]
        );

        $this->add_control(
                'about_us_content',
                [
                        'label'   => esc_html__( 'Content', 'medilac' ),
                        'type'    => Controls_Manager::TEXTAREA,
                        'default' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, porro harum quam, accusamus quaerat maiores fugit',
                ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Register About Us Read More Button
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_us_button(){
	$this->start_controls_section(
            'about_us_button',
            [
                'label'     => __( 'About Us Button', 'medilac' ),
                'condition'   => [
                    'about_style!' => '3',
                ],
            ]
        );
        $this->add_control(
            'about_btn_text',
            [
                'label'     => esc_html__( 'Text', 'medilac' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'Read More', 'medilac' ),
                'pleaceholder'  => __( 'Read More', 'medilac' ),
                'dynamic'       => [
                    'active'    => true,
                ]
            ]
        );
        $this->add_control(
            'about_btn_link',
            [
                'label'     => esc_html__( 'Link', 'medilac' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'medilac' ),
                'show_external' => true,
                'default' => [
                        'url' => '',
                        'is_external' => true,
                        'nofollow' => true,
                ],
            ]
        );

	$this->end_controls_section();
    }

    /**
     * Register About Us Video Button Settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_video_btn(){
	    $this->start_controls_section(
            'register_about_video_settings',
            [
                    'label'     => __( 'Video Button Settings', 'medilac' ),
            ]
        );
        $this->add_control(
            'video_btn_text',
            [
                'label'     => esc_html__( 'Text', 'medilac' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => __( 'view demo vido', 'medilac' ),
                'pleaceholder'  => __( 'view demo vido', 'medilac' ),
                'condition'   => [
                    'about_style' => '1',
                ],
                'dynamic'       => [
                    'active'    => true,
                ]
            ]
        );
        $this->add_control(
            'video_btn_link',
            [
                'label'     => esc_html__( 'Video Link', 'medilac' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://www.youtube.com/watch?v=Mi4JcBA-Ffw', 'medilac' ),
                'show_external' => true,
                'default' => [
                        'url' => '',
                        'is_external' => true,
                        'nofollow' => true,
                ],
            ]
        );
        $this->end_controls_section();
    }
   
    /**
     * Package Ribbon style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_ribbon_style(){
	$this->start_controls_section(
	            'ribbon_style_settings',
                [
                    'label'     => esc_html__( 'Ribbon Text', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'condition'   => [
                        'about_style' => '1',
                    ],
                ]
        );
        $this->add_control(
            'about_ribbon_content_normal', [
                'label'     => esc_html__( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .medilac-content .exp-box' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'ribbon_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-content .exp-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'ribbon_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-content .exp-box',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'ribbon_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .medilac-content .exp-box',
            )
        );
        $this->add_responsive_control(
            'ribbon_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-content .exp-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'ribbon_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-content .exp-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'ribbon_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .medilac-content .exp-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'ribbon_shadow',
                'selector' => '{{WRAPPER}} .medilac-content .exp-box',
            )
        );
        $this->end_controls_section();
    }
    
    
    /**
     * Register Sub Title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_sub_title_style() {
        $this->start_controls_section(
            'section_about_sub_title_style',
            [
                'label'      => __( 'Sub Title', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'about_us_sub_title_item_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .medilac-content .content-title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'about_us_title_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .medilac-content .content-title span',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'about_us_sub_shadow',
                'selector'  => '{{WRAPPER}} .medilac-content .content-title span',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'about_us_sub_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-content .content-title span',
            ]
        );
        $this->add_control(
            'about_us_sub_title_color',
            [
                'label' => __( 'Item Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .medilac-content .content-title span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    
    
    /**
     * Register Title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_about_title_style() {
        $this->start_controls_section(
            'section_about_title_style',
            [
                'label'      => __( 'Title', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'about_title_item_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .medilac-content .content-title h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'about_us_titles_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'abouts_us_sub_shadow',
                'selector'  => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'about_us_title_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .medilac-content .content-title h4',
            ]
        );
        $this->add_control(
            'about_us_title_color',
            [
                'label' => __( 'Item Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .medilac-content .content-title h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Render About us image
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
     public function render_about_us_image(){
        $settings   = $this->get_settings_for_display();
        $about_image               = isset( $settings['about_image']['url'] ) ? $settings['about_image']['url'] : '';
        if(!empty( $about_image )){?>
            <img src="<?php echo esc_url( $about_image ); ?>" alt="<?php esc_attr__( 'About Us', 'medilac' )?>">
        <?php }
    }
     
    /**
     * Render Ribbon settings
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function render_ribbon_content(){
        $settings   = $this->get_settings_for_display();
        $ribbon_content   = isset( $settings['ribbon_content'] ) ? $settings['ribbon_content'] : '';
        if(!empty( $ribbon_content )){?>
            <div class="exp-box">
                <?php echo wp_kses_post( $ribbon_content );?>
            </div>
        <?php }
     }
     
    /**
     * Render Section title
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
     public function render_section_title(){
        $settings   = $this->get_settings_for_display();
        $about_sub_title   = isset( $settings['about_sub_title'] ) ? $settings['about_sub_title'] : '';
        $about_title   = isset( $settings['about_title'] ) ? $settings['about_title'] : '';
        if( ! empty( $about_sub_title ) || !empty( $about_title ) ){?>
            <div class="content-title">
                <?php if(!empty( $about_sub_title )) : ?>
                <span><?php echo esc_html( $about_sub_title ); ?></span>
                <?php endif; ?>
                <?php if(!empty( $about_title )) : ?>
                <h4><?php echo esc_html( $about_title );?></h4>
                <?php endif; ?>
            </div>
        <?php }
     }
     
    /**
     * Render About Us Contents
     * 
     * @access protected
     * 
     * @since 1.0.0
     */  
    public function render_about_us_contents(){
        $settings   = $this->get_settings_for_display();
        $about_us_content   = isset( $settings['about_us_content'] ) ? $settings['about_us_content'] : '';
        if( ! empty( $about_us_content ) ){?>
            <div class="medilac-content">
                <?php echo wp_kses_post( $about_us_content );?>
            </div>
        <?php }
     }
     
    /**
     * Render About Us Button
     * 
     * @access protected
     * 
     * @since 1.0.0
     */  
    public function render_about_read_more(){
        $settings   = $this->get_settings_for_display();
        $about_btn_text       = isset( $settings['about_btn_text'] ) ? $settings['about_btn_text'] : '';
        $ab_link              = isset( $settings['about_btn_link']['url'] ) ? $settings['about_btn_link']['url'] : '';
        $ab_target            = $settings['about_btn_link']['is_external'] ? ' target="_blank"' : '';
        $ab_nofollow          = $settings['about_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
        if( ! empty( $about_btn_text ) ){ ?>
            <a href="<?php echo esc_url( $ab_link );?>" <?php echo esc_attr($ab_target);?> <?php echo esc_attr($ab_nofollow);?> class="btn v3 medilac-btn"><?php echo esc_html( $about_btn_text );?></a>
        <?php }
     }
     
    /**
     * Render About Video Button
     * 
     * @access protected
     * 
     * @since 1.0.0
     */  
    public function render_about_video_btn(){
        $settings   = $this->get_settings_for_display();
        $video_btn_text          = isset( $settings['video_btn_text'] ) ? $settings['video_btn_text'] : '';
        $video_link              = isset( $settings['video_btn_link']['url'] ) ? $settings['video_btn_link']['url'] : '';
        $video_target            = $settings['video_btn_link']['is_external'] ? ' target="_blank"' : '';
        $video_nofollow          = $settings['video_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
        if( ! empty( $video_btn_text ) ){ ?>
            <a href="<?php echo esc_url( $video_link );?>" <?php echo esc_attr( $video_target );?> <?php echo esc_attr( $video_nofollow );?> class="video-btn"><span class="fas fa-play"></span><?php echo esc_html( $video_btn_text );?></a>
        <?php }
     }
     
    /**
     * Render About Video Overlay
     * 
     * @access protected
     * 
     * @since 1.0.0
     */  
    public function render_overlay_video_btn(){
        $settings   = $this->get_settings_for_display();
        $video_link              = isset( $settings['video_btn_link']['url'] ) ? $settings['video_btn_link']['url'] : '';
        $video_target            = $settings['video_btn_link']['is_external'] ? ' target="_blank"' : '';
        $video_nofollow          = $settings['video_btn_link']['nofollow'] ? ' rel="nofollow"' : '';
        if( ! empty( $video_link ) ){ ?>
            <a href="<?php echo esc_url( $video_link )?>" <?php echo esc_attr( $video_target );?> <?php echo esc_attr( $video_nofollow );?> class="play-btn">
                <img src="<?php echo get_template_directory_uri().'/assets/images/about_play.png';?>" alt="<?php esc_attr__('image', 'medilac');?>">
            </a>
        <?php }
     }
     
     
    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings   = $this->get_settings_for_display();
        if( isset( $settings['about_style'] ) && '1' == $settings['about_style'] ){?>
        <!-- About Section start-->
        <section class="about-area section-padding medilac-content">
            <div class="medilac-home-container">
                <div class="row">
                    <div class="about-wrap">
                        <div class="about-img">
                            <?php $this->render_about_us_image();?>
                            <?php $this->render_ribbon_content();?>
                        </div>
                        <div class="about-content">
                             <?php $this->render_section_title();?>
                            <div class="content-text">
                                <?php $this->render_about_us_contents();?>
                            </div>
                            <div class="about-btn">
                                <?php $this->render_about_read_more();?>
                                <?php $this->render_about_video_btn();?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Section end-->
        <?php }elseif('2' == $settings['about_style']) {?>
        <!-- About  section start -->
        <section class="about-area v2 section-padding medilac-content">
            <div class="medilac-home-container">
                <div class="row">
                    <div class="about-wrap">
                        <div class="about-img">
                            <?php $this->render_about_us_image();?>
                        </div>
                        <div class="about-content">
                            <div class="content-title">
                                <?php $this->render_section_title();?>
                            </div>
                            <div class="content-text">
                                <?php $this->render_about_us_contents();?>
                            </div>
                            <div class="about-btn">
                                <?php $this->render_about_read_more();?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About section end -->
        <?php }elseif('3' == $settings['about_style']){?>
        <!-- About Section start-->
        <section class="page-template-template-home3 section-padding medilac-content">
          <div class="medilac-home-container about-area">
            <div class="row">
              <div class="about-wrap">
                <div class="about-img">
                  <?php $this->render_about_us_image();?>
                  <?php $this->render_overlay_video_btn();?>
                </div>
                <div class="about-content">
                  <div class="content-title">
                    <?php $this->render_section_title();?>
                  </div>  
                  <?php $this->render_about_us_contents();?>
              </div>
            </div>
          </div>
        </section>
        <!-- About Section end-->
        <?php }
    }
    
    protected function _content_template() {}
    
}
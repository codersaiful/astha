<?php
//namespace Medilac;
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Medilac_Widget_Testimonial extends Widget_Base{
    
    /**
     * Widget Pricing Testimonial 
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Name.
     */
    public function get_name() {
        return 'medilac_widget_testimonial';
    }
    
    /**
     * Widget Title.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Title.
     */
    public function get_title() {
        return __( 'Testimonial Section', 'medilac' );
    }
    
    public function get_custom_help_url() {
            return 'https://example.com/Medilac_Widget_Testimonial';
    }

    
    /**
     * Widget Icon.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Icon.
     */
    public function get_icon() {
        return 'eicon-testimonial';
    }
    
    public function get_keywords() {
            return [ 'testimonial', 'review', 'rewiews', 'ratings', 'medilac' ];
    }
    /**
     * Widget Category.
     *
     * Holds the Repeater counter data. Default is `0`.
     *
     * @since 1.0.0
     * @static
     *
     * @var int Widget Category.
     */
    public function get_categories() {
        return [ 'medilac' ];
    }
    
    /**
     * Register oEmbed widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _register_controls() {
        // Register testimonial style
        $this->register_general_controls();
        // Register Item
        $this->register_content_controls();
        // Testimonial items style
        $this->register_testimonial_item_style();
        // Testimonial Author Name Style
        $this->register_author_name();
        // Testimonial Author Designation
        $this->register_author_designation();
        // Testimonial Quote style
        $this->register_quote_style();
        // Testimonial Navigation style
        $this->register_navigation_style();
    }
    
    /**
     * Register Price Testimonial General Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_general_controls(){
        $this->start_controls_section(
            'testimonial_table_top',
            [
                'label'     => esc_html__( 'General', 'medilac' ),
            ]
        );
        $this->add_control(
            'testimonial_style',
            [
                'label'     => esc_html__( 'Testimonial Style', 'medilac' ),
                'type'      => Controls_Manager::SELECT,
                'label_block'   => true,
                'options'       => [
                    '1'         => esc_html__( 'Style 01', 'medilac' ),
                    '2'         => esc_html__( 'Style 02', 'medilac' ),
                ],
                'default'       => '1',
            ]
        );
        $this->end_controls_section();
    }
  
    /**
     * Register Price Testimonial Content Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_content_controls(){
	    $this->start_controls_section(
	            'section_features',
                [
                        'label'     => __( 'Testimonial Items', 'medilac' ),
                ]
            );
            $this->add_control(
            'items',
            [
                'label'         => esc_html__( 'Testimonial Items', 'medilac' ),
                'type'          => Controls_Manager::REPEATER,
                'separator'     => 'before',
                'default'       => [
                    [
                        'testimonial_content'   => 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor
                incdidunt ut labore et dolore magna do aliqua quis ipsum suspendisse ces gravida.',
                        'author_name'           => 'Jhonny Robartson',
                        'author_designation'    => 'UI/UX Designer',
                    ],
                    [
                        'testimonial_content'   => 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor
                incdidunt ut labore et dolore magna do aliqua quis ipsum suspendisse ces gravida.',
                        'author_name'           => 'Jhonny Robartson',
                        'author_designation'    => 'UI/UX Designer',
                    ],
                    [
                        'testimonial_content'   => 'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor
                incdidunt ut labore et dolore magna do aliqua quis ipsum suspendisse ces gravida.',
                        'author_name'           => 'Jhonny Robartson',
                        'author_designation'    => 'UI/UX Designer',
                    ],
                    
                ],
                'fields'        => [
                    [
                        'name'          => 'testimonial_content',
                        'label'         => esc_html__( 'Testimonial Content', 'medilac' ),
                        'type'          => Controls_Manager::TEXTAREA,
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'author_thumb',
                        'label'         => esc_html__( 'Add Author Image', 'medilac' ),
                        'type'          => Controls_Manager::MEDIA,
                        'default' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'author_name',
                        'label'         => esc_html__( 'Author Name', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block'   => true,
                    ],
                    [
                        'name'          => 'author_designation',
                        'label'         => esc_html__( 'Author Designation:', 'medilac' ),
                        'type'          => Controls_Manager::TEXT,
                        'label_block'   => true,
                    ],
                ],
                'title_field' => '{{{ author_name }}}',
            ]
        );
	$this->end_controls_section();
    }

    /**
     * Register Price Testimonial Heading Style Controls.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_heading_style_controls(){
	    $this->start_controls_section(
	            'section_header_style',
                [
                    'label'    => __( 'Heading', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                    'show_label' => false,
                ]
        );
        $this->add_control(
            'heading_style',
            [
                'label'     => __( 'Title', 'medilac' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'heading_tag',
            [
                'label'   => __( 'Title Tag', 'medilac' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'h1'  => __( 'H1', 'medilac' ),
                    'h2'  => __( 'H2', 'medilac' ),
                    'h3'  => __( 'H3', 'medilac' ),
                    'h4'  => __( 'H4', 'medilac' ),
                    'h5'  => __( 'H5', 'medilac' ),
                    'h6'  => __( 'H6', 'medilac' ),
                    'div' => __( 'div', 'medilac' ),
                    'p'   => __( 'p', 'medilac' ),
                ],
                'default' => 'p',
            ]
        );
        $this->add_control(
            'heading_color',
            [
                'label'     => __( 'Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'scheme'    => [
                    'type'  => Scheme_Color::get_type(),
                    'value' => Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_typography',
                'selector' => '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading',
                'scheme'   => Scheme_Typography::TYPOGRAPHY_1,
            ]
        );
        $this->add_responsive_control(
            'header_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'header_margin',
            [
                'label'      => __( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'heading_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading',
            ]
        );
        $this->add_control(
            'testimonial_heading_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-box-item .testimonial-icon .medilac-price-table-heading' => 'text-align: {{VALUE}}',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Testimonial Item Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_testimonial_item_style(){
	    $this->start_controls_section(
	            'regular_sell_style_label',
                [
                    'label'     => esc_html__( 'Testimonial Item', 'medilac' ),
                    'tab'      => Controls_Manager::TAB_STYLE,
                ]

        );
        $this->add_control(
            'testimonial_content_normal', [
                'label'     => esc_html__( 'Content Color', 'medilac' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'scheme'    => [
                    'type'      => Scheme_Color::get_type(),
                    'value'     => Scheme_Color::COLOR_1,
                ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'color: {{value}};',
                ]
            ]
        );
        $this->add_responsive_control(
            'testimonial_contents_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'testimonial_content_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .testimonial-slider .item p.client-quote',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'        => 'testimonial_content_border',
                'label'       => esc_html__( 'Border', 'medilac' ),
                'placeholder' => '1px',
                'default'     => '',
                'selector'    => '{{WRAPPER}} .testimonial-slider .item p.client-quote',
            )
        );
        $this->add_responsive_control(
            'testimonial_content_padding',
            array(
                'label'      => esc_html__( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'testimonial_content_margin',
            array(
                'label'      => esc_html__( 'Margin', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%', 'em' ),
                'selectors'  => array(
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_responsive_control(
            'testimonial_radius',
            array(
                'label'      => __( 'Border Radius', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => array( 'px', '%' ),
                'selectors'  => array(
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'testimonial_shadow',
                'selector' => '{{WRAPPER}} .testimonial-slider .item p.client-quote',
            )
        );
        $this->add_control(
            'testimonial_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors'     => [
                    '{{WRAPPER}} .testimonial-slider .item p.client-quote' => 'text-align: {{value}};',
                ],
                'default' => '',
                'toggle' => true,
            ]
        );
	    $this->end_controls_section();
    }
    
    
    /**
     * Testimonial Author Name Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_author_name() {
        $this->start_controls_section(
            'author_name_style',
            [
                'label'      => __( 'Auhor name', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'author_name_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-area .client-name p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'author_name_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .testimonial-area .client-name p',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'author_name_shadow',
                'selector'  => '{{WRAPPER}} .testimonial-area .client-name p',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_name_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .testimonial-area .client-name p',
            ]
        );
        $this->add_control(
            'author_name_color',
            [
                'label' => __( 'Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-area .client-name p' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'author_name_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-area .client-name p' => 'text-align: {{VALUE}}',
                ],
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Testimonial Quote Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_quote_style() {
        $this->start_controls_section(
            'testimonial_style',
            [
                'label'      => __( 'Testimonial Quote', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->add_control(
            'quote_text_color',
            [
                'label' => __( 'Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .client-quote-box span i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'testimonial_quote_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .client-quote-box span i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Testimonial Navigation Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_navigation_style() {
        $this->start_controls_section(
            'navigation_style',
            [
                'label'      => __( 'Navigation', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );
        $this->add_control(
            'quote_nav_color',
            [
                'label' => __( 'Navigation Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slider.v2 .owl-nav .owl-prev i, .testimonial-slider.v2 .owl-nav .owl-next i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'testimonial_navigation_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-slider.v2 .owl-nav .owl-prev i, .testimonial-slider.v2 .owl-nav .owl-next i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Testimonial Author Designation Style
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    protected function register_author_designation() {
        $this->start_controls_section(
            'author_des_style',
            [
                'label'      => __( 'Auhor Designation', 'medilac' ),
                'tab'        => Controls_Manager::TAB_STYLE,
                'show_label' => false,
            ]
        );

        $this->add_responsive_control(
            'author_des_padding',
            [
                'label'      => __( 'Padding', 'medilac' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-area .client-name span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'author_des_border',
                'label' => __( 'Border', 'medilac' ),
                'selector' => '{{WRAPPER}} .testimonial-area .client-name span',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'author_des_shadow',
                'selector'  => '{{WRAPPER}} .testimonial-area .client-name span',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_des_typography',
                'label' => __( 'Typography', 'medilac' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .testimonial-area .client-name span',
            ]
        );
        $this->add_control(
            'author_des_color',
            [
                'label' => __( 'Text Color', 'medilac' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-area .client-name span' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'author_designation_text_align',
            [
                'label' => __( 'Alignment', 'medilac' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'medilac' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'medilac' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'medilac' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-area .client-name span' => 'text-align: {{VALUE}}',
                ],
                'toggle' => true,
            ]
        );
        $this->end_controls_section();
    }
    
    /**
     * Price Features.
     * 
     * @access protected
     * 
     * @since 1.0.0
     */
    public function render_testimonial_items(){
        $settings = $this->get_settings();
        $items      = isset($settings['items']) ? $settings['items'] : '';
        if( ! empty( $settings['items'] ) ){
            foreach ($items as $item){ ?>
            <div class="item">
                <div class="client-quote-box">
                    <span class="quote-icon">
                      <i class="fas fa-quote-left"></i>
                    </span>
                    <?php if(!empty( $item['testimonial_content']) ) : ?>
                    <p class="client-quote"><?php echo esc_html( $item['testimonial_content'] );?></p>
                    <?php endif; ?>
                    <div class="client-info">
                        <?php if(!empty( $item['author_thumb']['url']) ) : ?>
                        <div class="client-img">
                            <img src="<?php echo esc_url( $item['author_thumb']['url'] );?>" alt="<?php esc_html__('Image', 'medilac'); ?>">
                        </div>
                        <?php endif; ?>
                        <div class="client-name">
                            <?php if(!empty( $item['author_name'] )) : ?>
                            <p><?php echo esc_html( $item['author_name'] );?></p>
                            <?php endif;?>
                            <?php if(!empty( $item['author_designation'] )) : ?>
                            <span><?php echo esc_html( $item['author_designation'] );?></span>
                           <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>      
            <?php }
        }
    }

    /**
     * Render oEmbed widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings();
        if( isset( $settings['testimonial_style'] ) && '1' == $settings['testimonial_style'] ){?>
             <!-- Testimonial section start -->
            <section class="testimonial-area v1 section-padding">
              <div class="medilac-home-container-fluid">
                <div class="row">
                  <div class="owl-carousel testimonial-slider v1">
                      <?php $this->render_testimonial_items();?>
                  </div>
                </div>
              </div>
            </section>
            <!-- Testimonial section ends -->
        <?php }else {?>
          <!-- Testimonial slider section start -->
          <section class="testimonial-area v2 section-padding">
              <div class="medilac-home-container">
                  <div class="row">
                      <div class="testimonial-slider v2 owl-carousel">
                           <?php $this->render_testimonial_items();?>
                      </div>
                  </div>
              </div>
          </section>
          <!-- Testimonial slider section end -->
        <?php }
    }
    
    protected function _content_template() {}
    
}